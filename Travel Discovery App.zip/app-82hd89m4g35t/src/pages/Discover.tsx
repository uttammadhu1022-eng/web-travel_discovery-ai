import React, { useState } from 'react';
import { Compass, Search, Loader2, MapPin, Clock, Video } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import PageMeta from '@/components/common/PageMeta';
import { aiAPI } from '@/services/api';
import ReactMarkdown from 'react-markdown';

interface DestinationData {
  name: string;
  country: string;
  description: string;
  historicalInfo: string;
  attractions: Array<{ name: string; description: string; type: string }>;
  videos: Array<{ title: string; url: string }>;
}

const Discover: React.FC = () => {
  const [destination, setDestination] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [destinationData, setDestinationData] = useState<DestinationData | null>(null);

  const handleDiscover = async () => {
    if (!destination.trim()) {
      toast.error('Please enter a destination');
      return;
    }

    setIsLoading(true);

    try {
      const prompt = `Provide comprehensive information about ${destination} in the following JSON format:
{
  "name": "destination name",
  "country": "country name",
  "description": "brief overview",
  "historicalInfo": "detailed historical background and significance",
  "attractions": [
    {"name": "attraction name", "description": "description", "type": "museum/landmark/nature/etc"}
  ],
  "videos": [
    {"title": "video title", "url": "youtube embed url like https://www.youtube.com/embed/VIDEO_ID"}
  ]
}

Include 5-7 top attractions and 3-4 relevant YouTube video URLs.`;

      const result = await aiAPI.generateContent(prompt);
      
      // Extract JSON from markdown code blocks if present
      let jsonStr = result;
      const jsonMatch = result.match(/```json\n([\s\S]*?)\n```/);
      if (jsonMatch) {
        jsonStr = jsonMatch[1];
      }

      const data = JSON.parse(jsonStr);
      setDestinationData(data);
      toast.success('Destination information loaded!');
    } catch (error) {
      console.error('Error fetching destination info:', error);
      toast.error('Failed to load destination information');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <PageMeta title="Discover - Travel Discovery" description="Explore destinations with historical insights" />
      
      <div className="min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <Compass className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Discover Destinations</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Explore historical information, attractions, and videos about any destination
            </p>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Search Destination</CardTitle>
              <CardDescription>Enter a city or landmark to discover</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <div className="flex-1 space-y-2">
                  <Label htmlFor="destination">Destination</Label>
                  <Input
                    id="destination"
                    placeholder="e.g., Paris, Machu Picchu, Tokyo"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleDiscover()}
                  />
                </div>
                <div className="flex items-end">
                  <Button onClick={handleDiscover} disabled={isLoading}>
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                        Discovering...
                      </>
                    ) : (
                      <>
                        <Search className="mr-2 w-4 h-4" />
                        Discover
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {destinationData && (
            <div className="space-y-8">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-3xl">{destinationData.name}</CardTitle>
                      <CardDescription className="text-lg mt-2">
                        <MapPin className="w-4 h-4 inline mr-1" />
                        {destinationData.country}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="text-xl font-semibold mb-3">Overview</h3>
                    <p className="text-muted-foreground">{destinationData.description}</p>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold mb-3 flex items-center">
                      <Clock className="w-5 h-5 mr-2" />
                      Historical Background
                    </h3>
                    <div className="prose prose-sm max-w-none text-muted-foreground">
                      <ReactMarkdown>{destinationData.historicalInfo}</ReactMarkdown>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div>
                <h2 className="text-2xl font-bold mb-6">Top Attractions</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {destinationData.attractions.map((attraction, index) => (
                    <Card key={index} className="travel-card">
                      <CardHeader>
                        <CardTitle className="text-lg">{attraction.name}</CardTitle>
                        <Badge variant="secondary" className="w-fit">
                          {attraction.type}
                        </Badge>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground">
                          {attraction.description}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {destinationData.videos && destinationData.videos.length > 0 && (
                <div>
                  <h2 className="text-2xl font-bold mb-6 flex items-center">
                    <Video className="w-6 h-6 mr-2" />
                    Recommended Videos
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {destinationData.videos.map((video, index) => (
                      <Card key={index}>
                        <CardHeader>
                          <CardTitle className="text-base">{video.title}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="aspect-video">
                            <iframe
                              src={video.url}
                              title={video.title}
                              className="w-full h-full rounded-lg"
                              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                              allowFullScreen
                            />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Discover;
