import React from 'react';
import { Plane, Mail, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-card border-t border-border mt-auto">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Plane className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-lg font-bold gradient-text">
                Travel Discovery
              </span>
            </div>
            <p className="text-muted-foreground text-sm">
              Discover amazing destinations, connect with fellow travelers, and explore the world with AI-powered insights and a vibrant community.
            </p>
          </div>

          <div>
            <h3 className="text-base font-semibold text-foreground mb-4">
              Features
            </h3>
            <ul className="text-muted-foreground text-sm space-y-2">
              <li>AI Itinerary Generator</li>
              <li>Real-Time Weather & Events</li>
              <li>Smart Budget Tracker</li>
              <li>Multi-Language Translator</li>
              <li>Interactive Travel Map</li>
              <li>Travel Journal</li>
            </ul>
          </div>

          <div>
            <h3 className="text-base font-semibold text-foreground mb-4">
              Connect
            </h3>
            <div className="text-muted-foreground text-sm space-y-3">
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4" />
                <span>Explore destinations worldwide</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <span>support@travelassistant.com</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border text-center text-muted-foreground text-sm">
          <p>{currentYear} Travel Discovery</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
