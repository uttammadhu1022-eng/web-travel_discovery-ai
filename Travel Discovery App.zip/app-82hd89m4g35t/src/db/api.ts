import { supabase } from './supabase';
import type {
  Profile,
  Itinerary,
  BudgetEntry,
  PackingList,
  TravelJournal,
  SavedDestination,
} from '@/types';

export const getUserUUID = (): string => {
  let uuid = localStorage.getItem('travel_user_uuid');
  if (!uuid) {
    uuid = crypto.randomUUID();
    localStorage.setItem('travel_user_uuid', uuid);
  }
  return uuid;
};

export const getOrCreateProfile = async (): Promise<Profile | null> => {
  const userUUID = getUserUUID();
  
  const { data: existing } = await supabase
    .from('profiles')
    .select('*')
    .eq('user_uuid', userUUID)
    .maybeSingle();

  if (existing) {
    return existing;
  }

  const { data, error } = await supabase
    .from('profiles')
    .insert({ user_uuid: userUUID })
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating profile:', error);
    return null;
  }

  return data;
};

export const updateProfile = async (updates: Partial<Profile>): Promise<Profile | null> => {
  const userUUID = getUserUUID();

  const { data, error } = await supabase
    .from('profiles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('user_uuid', userUUID)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error updating profile:', error);
    return null;
  }

  return data;
};

export const getItineraries = async (): Promise<Itinerary[]> => {
  const userUUID = getUserUUID();

  const { data, error } = await supabase
    .from('itineraries')
    .select('*')
    .eq('user_uuid', userUUID)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching itineraries:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
};

export const getItinerary = async (id: string): Promise<Itinerary | null> => {
  const { data, error } = await supabase
    .from('itineraries')
    .select('*')
    .eq('id', id)
    .maybeSingle();

  if (error) {
    console.error('Error fetching itinerary:', error);
    return null;
  }

  return data;
};

export const createItinerary = async (itinerary: Partial<Itinerary>): Promise<Itinerary | null> => {
  const userUUID = getUserUUID();

  const { data, error } = await supabase
    .from('itineraries')
    .insert({
      user_uuid: userUUID,
      title: itinerary.title || 'Untitled Trip',
      destination: itinerary.destination || '',
      start_date: itinerary.start_date,
      end_date: itinerary.end_date,
      budget: itinerary.budget,
      currency: itinerary.currency || 'USD',
      content: itinerary.content || {},
    })
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating itinerary:', error);
    return null;
  }

  return data;
};

export const updateItinerary = async (id: string, updates: Partial<Itinerary>): Promise<Itinerary | null> => {
  const { data, error } = await supabase
    .from('itineraries')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error updating itinerary:', error);
    return null;
  }

  return data;
};

export const deleteItinerary = async (id: string): Promise<boolean> => {
  const { error } = await supabase
    .from('itineraries')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Error deleting itinerary:', error);
    return false;
  }

  return true;
};

export const getBudgetEntries = async (itineraryId?: string): Promise<BudgetEntry[]> => {
  const userUUID = getUserUUID();

  let query = supabase
    .from('budget_entries')
    .select('*')
    .eq('user_uuid', userUUID);

  if (itineraryId) {
    query = query.eq('itinerary_id', itineraryId);
  }

  const { data, error } = await query.order('date', { ascending: false });

  if (error) {
    console.error('Error fetching budget entries:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
};

export const createBudgetEntry = async (entry: Partial<BudgetEntry>): Promise<BudgetEntry | null> => {
  const userUUID = getUserUUID();

  const { data, error } = await supabase
    .from('budget_entries')
    .insert({
      user_uuid: userUUID,
      itinerary_id: entry.itinerary_id,
      category: entry.category || 'Other',
      amount: entry.amount || 0,
      currency: entry.currency || 'USD',
      description: entry.description,
      date: entry.date || new Date().toISOString().split('T')[0],
    })
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating budget entry:', error);
    return null;
  }

  return data;
};

export const deleteBudgetEntry = async (id: string): Promise<boolean> => {
  const { error } = await supabase
    .from('budget_entries')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Error deleting budget entry:', error);
    return false;
  }

  return true;
};

export const getPackingLists = async (itineraryId?: string): Promise<PackingList[]> => {
  const userUUID = getUserUUID();

  let query = supabase
    .from('packing_lists')
    .select('*')
    .eq('user_uuid', userUUID);

  if (itineraryId) {
    query = query.eq('itinerary_id', itineraryId);
  }

  const { data, error } = await query.order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching packing lists:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
};

export const createPackingList = async (list: Partial<PackingList>): Promise<PackingList | null> => {
  const userUUID = getUserUUID();

  const { data, error } = await supabase
    .from('packing_lists')
    .insert({
      user_uuid: userUUID,
      itinerary_id: list.itinerary_id,
      title: list.title || 'Packing List',
      items: list.items || [],
    })
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating packing list:', error);
    return null;
  }

  return data;
};

export const updatePackingList = async (id: string, updates: Partial<PackingList>): Promise<PackingList | null> => {
  const { data, error } = await supabase
    .from('packing_lists')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error updating packing list:', error);
    return null;
  }

  return data;
};

export const deletePackingList = async (id: string): Promise<boolean> => {
  const { error } = await supabase
    .from('packing_lists')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Error deleting packing list:', error);
    return false;
  }

  return true;
};

export const getTravelJournals = async (itineraryId?: string): Promise<TravelJournal[]> => {
  const userUUID = getUserUUID();

  let query = supabase
    .from('travel_journals')
    .select('*')
    .eq('user_uuid', userUUID);

  if (itineraryId) {
    query = query.eq('itinerary_id', itineraryId);
  }

  const { data, error } = await query.order('date', { ascending: false });

  if (error) {
    console.error('Error fetching travel journals:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
};

export const createTravelJournal = async (journal: Partial<TravelJournal>): Promise<TravelJournal | null> => {
  const userUUID = getUserUUID();

  const { data, error } = await supabase
    .from('travel_journals')
    .insert({
      user_uuid: userUUID,
      itinerary_id: journal.itinerary_id,
      title: journal.title || 'Journal Entry',
      content: journal.content,
      location: journal.location,
      latitude: journal.latitude,
      longitude: journal.longitude,
      photos: journal.photos || [],
      date: journal.date || new Date().toISOString().split('T')[0],
    })
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating travel journal:', error);
    return null;
  }

  return data;
};

export const updateTravelJournal = async (id: string, updates: Partial<TravelJournal>): Promise<TravelJournal | null> => {
  const { data, error } = await supabase
    .from('travel_journals')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error updating travel journal:', error);
    return null;
  }

  return data;
};

export const deleteTravelJournal = async (id: string): Promise<boolean> => {
  const { error } = await supabase
    .from('travel_journals')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Error deleting travel journal:', error);
    return false;
  }

  return true;
};

export const getSavedDestinations = async (): Promise<SavedDestination[]> => {
  const userUUID = getUserUUID();

  const { data, error } = await supabase
    .from('saved_destinations')
    .select('*')
    .eq('user_uuid', userUUID)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching saved destinations:', error);
    return [];
  }

  return Array.isArray(data) ? data : [];
};

export const createSavedDestination = async (destination: Partial<SavedDestination>): Promise<SavedDestination | null> => {
  const userUUID = getUserUUID();

  const { data, error } = await supabase
    .from('saved_destinations')
    .insert({
      user_uuid: userUUID,
      name: destination.name || '',
      country: destination.country,
      description: destination.description,
      notes: destination.notes,
      latitude: destination.latitude,
      longitude: destination.longitude,
    })
    .select()
    .maybeSingle();

  if (error) {
    console.error('Error creating saved destination:', error);
    return null;
  }

  return data;
};

export const deleteSavedDestination = async (id: string): Promise<boolean> => {
  const { error } = await supabase
    .from('saved_destinations')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Error deleting saved destination:', error);
    return false;
  }

  return true;
};
