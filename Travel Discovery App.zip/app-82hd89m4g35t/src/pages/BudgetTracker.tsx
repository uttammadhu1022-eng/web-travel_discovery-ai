import React, { useState, useEffect } from 'react';
import { Wallet, Plus, Trash2, DollarSign } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import PageMeta from '@/components/common/PageMeta';
import { getBudgetEntries, createBudgetEntry, deleteBudgetEntry } from '@/db/api';
import type { BudgetEntry } from '@/types';

const BudgetTracker: React.FC = () => {
  const [entries, setEntries] = useState<BudgetEntry[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [category, setCategory] = useState('');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    loadEntries();
  }, []);

  const loadEntries = async () => {
    const data = await getBudgetEntries();
    setEntries(data);
  };

  const handleAdd = async () => {
    if (!category || !amount) {
      toast.error('Please fill in required fields');
      return;
    }

    await createBudgetEntry({
      category,
      amount: Number.parseFloat(amount),
      description,
      date,
      currency: 'USD',
    });

    toast.success('Expense added!');
    setIsDialogOpen(false);
    setCategory('');
    setAmount('');
    setDescription('');
    await loadEntries();
  };

  const handleDelete = async (id: string) => {
    await deleteBudgetEntry(id);
    toast.success('Expense deleted');
    await loadEntries();
  };

  const totalSpent = entries.reduce((sum, entry) => sum + entry.amount, 0);

  const categories = ['Accommodation', 'Food', 'Transport', 'Activities', 'Shopping', 'Other'];

  return (
    <>
      <PageMeta title="Budget Tracker - Travel Assistant" description="Track your travel expenses" />
      
      <div className="min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <Wallet className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Budget Tracker</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Track your travel expenses and stay within budget
            </p>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Total Spent</CardTitle>
                <CardDescription>All expenses</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold text-primary">
                  ${totalSpent.toFixed(2)}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Entries</CardTitle>
                <CardDescription>Total transactions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold">{entries.length}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Average</CardTitle>
                <CardDescription>Per transaction</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold">
                  ${entries.length > 0 ? (totalSpent / entries.length).toFixed(2) : '0.00'}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Expenses</h2>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 w-4 h-4" />
                  Add Expense
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Expense</DialogTitle>
                  <DialogDescription>Record a new travel expense</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Category *</Label>
                    <Select value={category} onValueChange={setCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Amount (USD) *</Label>
                    <Input type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Input value={description} onChange={(e) => setDescription(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Date</Label>
                    <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>
                  <Button onClick={handleAdd} className="w-full">Add Expense</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {entries.map((entry) => (
              <Card key={entry.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{entry.category}</CardTitle>
                      <CardDescription>{entry.description}</CardDescription>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(entry.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div className="text-2xl font-bold text-primary">
                      ${entry.amount.toFixed(2)}
                    </div>
                    <div className="text-sm text-muted-foreground">{entry.date}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default BudgetTracker;
