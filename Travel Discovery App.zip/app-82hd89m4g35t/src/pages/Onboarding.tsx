import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, Loader2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';
import PageMeta from '@/components/common/PageMeta';

const Onboarding: React.FC = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [bio, setBio] = useState('');

  const interests = [
    'Adventure & Hiking',
    'Beach & Relaxation',
    'Cultural & Historical Sites',
    'Food & Culinary',
    'Photography',
    'Wildlife & Nature',
    'City Exploration',
    'Luxury Travel',
    'Budget Travel',
    'Solo Travel',
    'Family Travel',
    'Backpacking',
  ];

  const toggleInterest = (interest: string) => {
    setSelectedInterests((prev) =>
      prev.includes(interest)
        ? prev.filter((i) => i !== interest)
        : [...prev, interest]
    );
  };

  const handleComplete = async () => {
    if (selectedInterests.length === 0) {
      toast.error('Please select at least one travel interest');
      return;
    }

    setIsLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast.error('Please log in first');
        navigate('/login');
        return;
      }

      const { error } = await supabase
        .from('profiles')
        .update({
          travel_interests: selectedInterests,
          bio: bio || null,
        })
        .eq('id', user.id);

      if (error) throw error;

      toast.success('Profile updated! Welcome to Travel Discovery!');
      navigate('/');
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error('Failed to update profile');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <PageMeta title="Welcome - Travel Discovery" description="Tell us about your travel interests" />
      
      <div className="min-h-screen py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <Sparkles className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Welcome to Travel Discovery!</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Let's personalize your experience. Tell us about your travel interests.
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>What are your travel interests?</CardTitle>
              <CardDescription>
                Select all that apply. This helps us provide better recommendations.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {interests.map((interest) => (
                  <div key={interest} className="flex items-center space-x-2">
                    <Checkbox
                      id={interest}
                      checked={selectedInterests.includes(interest)}
                      onCheckedChange={() => toggleInterest(interest)}
                    />
                    <Label
                      htmlFor={interest}
                      className="text-sm font-normal cursor-pointer"
                    >
                      {interest}
                    </Label>
                  </div>
                ))}
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Tell us about yourself (Optional)</Label>
                <Textarea
                  id="bio"
                  placeholder="Share your travel dreams, favorite destinations, or what you're looking for..."
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  rows={4}
                />
              </div>

              <Button
                onClick={handleComplete}
                disabled={isLoading || selectedInterests.length === 0}
                className="w-full"
                size="lg"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 w-5 h-5 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Complete Setup'
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
};

export default Onboarding;
