import React, { useState, useEffect } from 'react';
import { Languages, ArrowRight, Loader2, Mic, Volume2, MicOff, VolumeX } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import PageMeta from '@/components/common/PageMeta';
import { translationAPI } from '@/services/api';
import {
  startSpeechRecognition,
  stopSpeechRecognition,
  speakText,
  stopSpeaking,
  isSpeechRecognitionSupported,
  isSpeechSynthesisSupported,
  loadVoices,
} from '@/services/voiceService';

const Translator: React.FC = () => {
  const [sourceText, setSourceText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [sourceLang, setSourceLang] = useState('en');
  const [targetLang, setTargetLang] = useState('es');
  const [isTranslating, setIsTranslating] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);
  const [speechSupported, setSpeechSupported] = useState({
    recognition: false,
    synthesis: false,
  });

  const languages = [
    { code: 'en', name: 'English' },
    { code: 'es', name: 'Spanish' },
    { code: 'fr', name: 'French' },
    { code: 'de', name: 'German' },
    { code: 'it', name: 'Italian' },
    { code: 'pt', name: 'Portuguese' },
    { code: 'zh', name: 'Chinese' },
    { code: 'ja', name: 'Japanese' },
    { code: 'ko', name: 'Korean' },
    { code: 'ar', name: 'Arabic' },
    { code: 'ru', name: 'Russian' },
  ];

  useEffect(() => {
    setSpeechSupported({
      recognition: isSpeechRecognitionSupported(),
      synthesis: isSpeechSynthesisSupported(),
    });

    if (isSpeechSynthesisSupported()) {
      loadVoices();
    }

    return () => {
      if (recognition) {
        stopSpeechRecognition(recognition);
      }
      stopSpeaking();
    };
  }, []);

  const handleTranslate = async () => {
    if (!sourceText.trim()) {
      toast.error('Please enter text to translate');
      return;
    }

    setIsTranslating(true);

    try {
      const result = await translationAPI.translate(sourceText, targetLang);
      setTranslatedText(result);
      toast.success('Translation complete!');
    } catch (error) {
      console.error('Translation error:', error);
      toast.error('Translation failed');
    } finally {
      setIsTranslating(false);
    }
  };

  const handleStartRecording = () => {
    if (!speechSupported.recognition) {
      toast.error('Speech recognition is not supported in your browser');
      return;
    }

    setIsRecording(true);

    const recognitionInstance = startSpeechRecognition(
      sourceLang,
      (transcript) => {
        setSourceText(transcript);
        toast.success('Speech recognized!');
      },
      (error) => {
        toast.error(error);
        setIsRecording(false);
      },
      () => {
        setIsRecording(false);
      }
    );

    setRecognition(recognitionInstance);
  };

  const handleStopRecording = () => {
    if (recognition) {
      stopSpeechRecognition(recognition);
      setIsRecording(false);
    }
  };

  const handleSpeak = () => {
    if (!speechSupported.synthesis) {
      toast.error('Speech synthesis is not supported in your browser');
      return;
    }

    if (!translatedText.trim()) {
      toast.error('No translation to speak');
      return;
    }

    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    speakText(
      translatedText,
      targetLang,
      () => {
        setIsSpeaking(true);
      },
      () => {
        setIsSpeaking(false);
      },
      (error) => {
        toast.error(error);
        setIsSpeaking(false);
      }
    );
  };

  const handleSpeakSource = () => {
    if (!speechSupported.synthesis) {
      toast.error('Speech synthesis is not supported in your browser');
      return;
    }

    if (!sourceText.trim()) {
      toast.error('No text to speak');
      return;
    }

    speakText(
      sourceText,
      sourceLang,
      () => {},
      () => {},
      (error) => {
        toast.error(error);
      }
    );
  };

  return (
    <>
      <PageMeta title="Translator - Travel Assistant" description="Translate text to any language with voice commands" />
      
      <div className="min-h-screen py-12">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <Languages className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Multi-Language Translator</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Communicate with locals and read signs in any language with voice commands
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Translate Text</CardTitle>
              <CardDescription>Enter text, use voice input, or listen to translations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Source Language</Label>
                  <Select value={sourceLang} onValueChange={setSourceLang}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map((lang) => (
                        <SelectItem key={lang.code} value={lang.code}>
                          {lang.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="relative">
                  <Textarea
                    placeholder="Enter text to translate or use voice input..."
                    value={sourceText}
                    onChange={(e) => setSourceText(e.target.value)}
                    rows={6}
                    className="pr-24"
                  />
                  <div className="absolute bottom-3 right-3 flex gap-2">
                    {sourceText && (
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={handleSpeakSource}
                        title="Listen to source text"
                      >
                        <Volume2 className="w-4 h-4" />
                      </Button>
                    )}
                    <Button
                      size="icon"
                      variant={isRecording ? 'destructive' : 'secondary'}
                      onClick={isRecording ? handleStopRecording : handleStartRecording}
                      disabled={!speechSupported.recognition}
                      title={isRecording ? 'Stop recording' : 'Start voice input'}
                      className={isRecording ? 'animate-pulse' : ''}
                    >
                      {isRecording ? (
                        <MicOff className="w-4 h-4" />
                      ) : (
                        <Mic className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </div>
                {isRecording && (
                  <p className="text-sm text-primary animate-pulse">
                    🎤 Listening... Speak now
                  </p>
                )}
              </div>

              <div className="flex items-center justify-center">
                <ArrowRight className="w-6 h-6 text-muted-foreground" />
              </div>

              <div className="space-y-2">
                <Label>Target Language</Label>
                <Select value={targetLang} onValueChange={setTargetLang}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {languages.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={handleTranslate} disabled={isTranslating} className="w-full" size="lg">
                {isTranslating ? (
                  <>
                    <Loader2 className="mr-2 w-5 h-5 animate-spin" />
                    Translating...
                  </>
                ) : (
                  <>
                    <Languages className="mr-2 w-5 h-5" />
                    Translate
                  </>
                )}
              </Button>

              {translatedText && (
                <div className="space-y-2">
                  <Label>Translation</Label>
                  <div className="relative bg-muted/30 p-4 rounded-lg min-h-[150px]">
                    <p className="text-lg pr-12">{translatedText}</p>
                    <div className="absolute top-4 right-4">
                      <Button
                        size="icon"
                        variant={isSpeaking ? 'destructive' : 'secondary'}
                        onClick={handleSpeak}
                        disabled={!speechSupported.synthesis}
                        title={isSpeaking ? 'Stop speaking' : 'Listen to translation'}
                        className={isSpeaking ? 'animate-pulse' : ''}
                      >
                        {isSpeaking ? (
                          <VolumeX className="w-4 h-4" />
                        ) : (
                          <Volume2 className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  {isSpeaking && (
                    <p className="text-sm text-primary animate-pulse">
                      🔊 Speaking translation...
                    </p>
                  )}
                </div>
              )}

              {(!speechSupported.recognition || !speechSupported.synthesis) && (
                <div className="bg-muted/50 p-4 rounded-lg text-sm text-muted-foreground">
                  <p className="font-semibold mb-2">Browser Compatibility Note:</p>
                  {!speechSupported.recognition && (
                    <p>• Voice input is not supported in your browser. Try Chrome, Edge, or Safari.</p>
                  )}
                  {!speechSupported.synthesis && (
                    <p>• Text-to-speech is not supported in your browser. Try Chrome, Edge, or Safari.</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
};

export default Translator;
