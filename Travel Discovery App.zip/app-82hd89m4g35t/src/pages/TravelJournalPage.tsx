import React, { useState, useEffect } from 'react';
import { BookOpen, Plus, Trash2, MapPin, Calendar } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import PageMeta from '@/components/common/PageMeta';
import { getTravelJournals, createTravelJournal, deleteTravelJournal } from '@/db/api';
import type { TravelJournal } from '@/types';

const TravelJournalPage: React.FC = () => {
  const [journals, setJournals] = useState<TravelJournal[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [location, setLocation] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    loadJournals();
  }, []);

  const loadJournals = async () => {
    const data = await getTravelJournals();
    setJournals(data);
  };

  const handleCreate = async () => {
    if (!title || !content) {
      toast.error('Please fill in required fields');
      return;
    }

    await createTravelJournal({
      title,
      content,
      location,
      date,
      photos: [],
    });

    toast.success('Journal entry created!');
    setIsDialogOpen(false);
    setTitle('');
    setContent('');
    setLocation('');
    setDate(new Date().toISOString().split('T')[0]);
    await loadJournals();
  };

  const handleDelete = async (id: string) => {
    await deleteTravelJournal(id);
    toast.success('Journal entry deleted');
    await loadJournals();
  };

  return (
    <>
      <PageMeta title="Travel Journal - Travel Assistant" description="Document your travel experiences" />
      
      <div className="min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <BookOpen className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Travel Journal</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Document your journey with photos, notes, and location tags
            </p>
          </div>

          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold">Journal Entries</h2>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 w-4 h-4" />
                  New Entry
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create Journal Entry</DialogTitle>
                  <DialogDescription>Record your travel memories</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Title *</Label>
                    <Input placeholder="e.g., Amazing day at the Louvre" value={title} onChange={(e) => setTitle(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Location</Label>
                    <Input placeholder="e.g., Paris, France" value={location} onChange={(e) => setLocation(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Date</Label>
                    <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Content *</Label>
                    <Textarea
                      placeholder="Write about your experience..."
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      rows={8}
                    />
                  </div>
                  <Button onClick={handleCreate} className="w-full">Create Entry</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {journals.map((journal) => (
              <Card key={journal.id} className="travel-card">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{journal.title}</CardTitle>
                      <CardDescription className="flex items-center gap-4 mt-2">
                        {journal.location && (
                          <span className="flex items-center">
                            <MapPin className="w-3 h-3 mr-1" />
                            {journal.location}
                          </span>
                        )}
                        <span className="flex items-center">
                          <Calendar className="w-3 h-3 mr-1" />
                          {new Date(journal.date).toLocaleDateString()}
                        </span>
                      </CardDescription>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(journal.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground line-clamp-4">
                    {journal.content}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          {journals.length === 0 && (
            <div className="text-center py-12">
              <BookOpen className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No journal entries yet. Start documenting your travels!</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default TravelJournalPage;
