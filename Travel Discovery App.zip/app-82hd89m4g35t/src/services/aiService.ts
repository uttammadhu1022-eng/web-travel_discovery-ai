interface Message {
  role: 'user' | 'model';
  parts: Array<{ text: string }>;
}

interface StreamResponse {
  candidates?: Array<{
    content?: {
      role: string;
      parts: Array<{ text: string }>;
    };
    finishReason?: string;
  }>;
}

export async function streamChatResponse(
  messages: Message[],
  onChunk: (text: string) => void,
  onComplete: () => void,
  onError: (error: string) => void
): Promise<void> {
  const appId = import.meta.env.VITE_APP_ID;
  const url = `https://api-integrations.appmedo.com/${appId}/api-rLob8RdzAOl9/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-App-Id': appId,
      },
      body: JSON.stringify({
        contents: messages,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      if (errorData.status === 999) {
        throw new Error(errorData.msg || 'API request failed');
      }
      throw new Error(`API request failed: ${response.statusText}`);
    }

    const reader = response.body?.getReader();
    const decoder = new TextDecoder();

    if (!reader) {
      throw new Error('Response body is not readable');
    }

    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      
      if (done) {
        onComplete();
        break;
      }

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.slice(6);
          
          if (data === '[DONE]') {
            onComplete();
            return;
          }

          try {
            const parsed: StreamResponse = JSON.parse(data);
            const text = parsed.candidates?.[0]?.content?.parts?.[0]?.text;
            
            if (text) {
              onChunk(text);
            }
          } catch (e) {
            console.error('Error parsing SSE data:', e);
          }
        }
      }
    }
  } catch (error) {
    console.error('Stream error:', error);
    onError(error instanceof Error ? error.message : 'An error occurred while communicating with the AI');
  }
}

export function createTravelSystemPrompt(): Message {
  return {
    role: 'model',
    parts: [{
      text: `You are a helpful AI Travel Assistant. Your role is to help users plan their trips, provide travel recommendations, answer questions about destinations, suggest activities, help with budgeting, and offer travel tips. 

Be friendly, informative, and concise. When suggesting destinations or activities, provide specific details like costs, best times to visit, and practical tips. If users ask about their itinerary or budget, help them organize and optimize their plans.

Always prioritize safety, cultural sensitivity, and sustainable travel practices in your recommendations.`
    }]
  };
}
