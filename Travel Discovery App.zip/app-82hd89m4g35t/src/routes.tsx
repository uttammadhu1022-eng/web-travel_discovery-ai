import type { ReactNode } from 'react';
import Home from './pages/Home';
import Login from './pages/Login';
import Onboarding from './pages/Onboarding';
import ItineraryGenerator from './pages/ItineraryGenerator';
import WeatherEvents from './pages/WeatherEvents';
import BudgetTracker from './pages/BudgetTracker';
import Translator from './pages/Translator';
import TravelMap from './pages/TravelMap';
import PackingList from './pages/PackingList';
import TravelJournalPage from './pages/TravelJournalPage';
import Discover from './pages/Discover';
import BookingAssistant from './pages/BookingAssistant';
import Community from './pages/Community';
import ProfilePage from './pages/Profile';
import AIAssistant from './pages/AIAssistant';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Login',
    path: '/login',
    element: <Login />,
    visible: false,
  },
  {
    name: 'Onboarding',
    path: '/onboarding',
    element: <Onboarding />,
    visible: false,
  },
  {
    name: 'Profile',
    path: '/profile',
    element: <ProfilePage />,
    visible: false,
  },
  {
    name: 'Home',
    path: '/',
    element: <Home />,
    visible: true,
  },
  {
    name: 'Discover',
    path: '/discover',
    element: <Discover />,
    visible: true,
  },
  {
    name: 'Community',
    path: '/community',
    element: <Community />,
    visible: true,
  },
  {
    name: 'AI Assistant',
    path: '/ai-assistant',
    element: <AIAssistant />,
    visible: true,
  },
  {
    name: 'AI Itinerary',
    path: '/itinerary',
    element: <ItineraryGenerator />,
    visible: true,
  },
  {
    name: 'Booking Assistant',
    path: '/booking',
    element: <BookingAssistant />,
    visible: true,
  },
  {
    name: 'Weather & Events',
    path: '/weather',
    element: <WeatherEvents />,
    visible: true,
  },
  {
    name: 'Budget Tracker',
    path: '/budget',
    element: <BudgetTracker />,
    visible: true,
  },
  {
    name: 'Translator',
    path: '/translator',
    element: <Translator />,
    visible: true,
  },
  {
    name: 'Travel Map',
    path: '/map',
    element: <TravelMap />,
    visible: true,
  },
  {
    name: 'Packing List',
    path: '/packing',
    element: <PackingList />,
    visible: true,
  },
  {
    name: 'Travel Journal',
    path: '/journal',
    element: <TravelJournalPage />,
    visible: true,
  },
];

export default routes;
