import React, { useCallback, useState, useEffect } from 'react';
import { GoogleMap, LoadScript, Marker, Polyline, InfoWindow } from '@react-google-maps/api';

interface RoutePoint {
  id: string;
  name: string;
  lat: number;
  lng: number;
  type: 'destination' | 'poi';
  category?: string;
  description?: string;
}

interface GoogleRouteMapProps {
  routePoints: RoutePoint[];
}

const mapContainerStyle = {
  width: '100%',
  height: '100%',
};

const defaultCenter = {
  lat: 40.7128,
  lng: -74.0060,
};

const GoogleRouteMap: React.FC<GoogleRouteMapProps> = ({ routePoints }) => {
  const [selectedMarker, setSelectedMarker] = useState<string | null>(null);
  const [map, setMap] = useState<google.maps.Map | null>(null);

  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

  const onLoad = useCallback((map: google.maps.Map) => {
    setMap(map);
  }, []);

  const onUnmount = useCallback(() => {
    setMap(null);
  }, []);

  // Fit bounds to show all markers
  useEffect(() => {
    if (map && routePoints.length > 0) {
      const bounds = new google.maps.LatLngBounds();
      routePoints.forEach(point => {
        bounds.extend({ lat: point.lat, lng: point.lng });
      });
      map.fitBounds(bounds);
    }
  }, [map, routePoints]);

  if (routePoints.length === 0) {
    return (
      <div className="h-full flex items-center justify-center bg-muted/20">
        <p className="text-muted-foreground">No route points to display</p>
      </div>
    );
  }

  if (!apiKey) {
    return (
      <div className="h-full flex items-center justify-center bg-muted/20">
        <div className="text-center p-8">
          <p className="text-muted-foreground mb-2">Google Maps API key not configured</p>
          <p className="text-sm text-muted-foreground">
            Please add VITE_GOOGLE_MAPS_API_KEY to your .env file
          </p>
        </div>
      </div>
    );
  }

  const center = routePoints.length > 0
    ? { lat: routePoints[0].lat, lng: routePoints[0].lng }
    : defaultCenter;

  const pathCoordinates = routePoints.map(point => ({
    lat: point.lat,
    lng: point.lng,
  }));

  return (
    <LoadScript googleMapsApiKey={apiKey}>
      <GoogleMap
        mapContainerStyle={mapContainerStyle}
        center={center}
        zoom={13}
        onLoad={onLoad}
        onUnmount={onUnmount}
        options={{
          streetViewControl: false,
          mapTypeControl: true,
          fullscreenControl: false,
        }}
      >
        {/* Route markers */}
        {routePoints.map((point, index) => (
          <Marker
            key={point.id}
            position={{ lat: point.lat, lng: point.lng }}
            label={{
              text: `${index + 1}`,
              color: 'white',
              fontSize: '14px',
              fontWeight: 'bold',
            }}
            onClick={() => setSelectedMarker(point.id)}
          />
        ))}

        {/* Info windows */}
        {routePoints.map((point, index) => (
          selectedMarker === point.id && (
            <InfoWindow
              key={`info-${point.id}`}
              position={{ lat: point.lat, lng: point.lng }}
              onCloseClick={() => setSelectedMarker(null)}
            >
              <div className="p-2">
                <p className="font-semibold text-sm">{point.name}</p>
                <p className="text-xs text-gray-600">
                  Stop {index + 1} of {routePoints.length}
                </p>
                {point.description && (
                  <p className="text-xs mt-1">{point.description}</p>
                )}
              </div>
            </InfoWindow>
          )
        ))}

        {/* Route line */}
        {routePoints.length > 1 && (
          <Polyline
            path={pathCoordinates}
            options={{
              strokeColor: '#1E88E5',
              strokeOpacity: 0.8,
              strokeWeight: 4,
            }}
          />
        )}
      </GoogleMap>
    </LoadScript>
  );
};

export default GoogleRouteMap;
