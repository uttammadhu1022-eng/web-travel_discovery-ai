// Translation service using Google Cloud Translation API

const TRANSLATION_API_URL = 'https://api-integrations.appmedo.com/app-82hd89m4g35t/api-eLMl28BvNej9/language/translate/v2';
const API_KEY = import.meta.env.VITE_TRANSLATION_API_KEY || 'miaoda-api-key';

export interface TranslationResult {
  translatedText: string;
  detectedSourceLanguage?: string;
}

export interface TranslationResponse {
  data: {
    translations: TranslationResult[];
  };
}

export const SUPPORTED_LANGUAGES = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Spanish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'it', name: 'Italian' },
  { code: 'pt', name: 'Portuguese' },
  { code: 'ru', name: 'Russian' },
  { code: 'ja', name: 'Japanese' },
  { code: 'ko', name: 'Korean' },
  { code: 'zh', name: 'Chinese (Simplified)' },
  { code: 'zh-TW', name: 'Chinese (Traditional)' },
  { code: 'ar', name: 'Arabic' },
  { code: 'hi', name: 'Hindi' },
  { code: 'th', name: 'Thai' },
  { code: 'vi', name: 'Vietnamese' },
  { code: 'id', name: 'Indonesian' },
  { code: 'tr', name: 'Turkish' },
  { code: 'pl', name: 'Polish' },
  { code: 'nl', name: 'Dutch' },
  { code: 'sv', name: 'Swedish' },
];

/**
 * Translate text to target language
 * @param text - Text to translate
 * @param targetLanguage - Target language code (e.g., 'es', 'fr', 'zh')
 * @param sourceLanguage - Optional source language code (auto-detected if not provided)
 * @returns Translated text and detected source language
 */
export const translateText = async (
  text: string,
  targetLanguage: string,
  sourceLanguage?: string
): Promise<TranslationResult> => {
  try {
    const payload: {
      q: string;
      target: string;
      source?: string;
      format: string;
    } = {
      q: text,
      target: targetLanguage,
      format: 'text',
    };

    if (sourceLanguage) {
      payload.source = sourceLanguage;
    }

    const response = await fetch(TRANSLATION_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': API_KEY,
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      if (errorData.status === 999) {
        throw new Error(errorData.msg || 'Translation failed');
      }
      throw new Error(`Translation failed: ${response.statusText}`);
    }

    const data: TranslationResponse = await response.json();
    
    if (!data.data?.translations?.[0]) {
      throw new Error('Invalid translation response');
    }

    return data.data.translations[0];
  } catch (error) {
    console.error('Translation error:', error);
    throw error;
  }
};

/**
 * Get language name from code
 */
export const getLanguageName = (code: string): string => {
  const language = SUPPORTED_LANGUAGES.find(lang => lang.code === code);
  return language?.name || code;
};

/**
 * Detect if text needs translation (simple heuristic)
 */
export const needsTranslation = (text: string, userLanguage: string): boolean => {
  // This is a simple check - in production, you might want to use language detection
  // For now, we'll always show the translate button
  return true;
};
