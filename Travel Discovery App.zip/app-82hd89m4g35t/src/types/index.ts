export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

export interface Profile {
  id: string;
  user_uuid: string;
  display_name: string | null;
  username?: string;
  email?: string;
  travel_interests?: string[];
  bio?: string;
  avatar_url?: string;
  role?: 'user' | 'admin';
  preferences: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface Itinerary {
  id: string;
  user_uuid: string;
  title: string;
  destination: string;
  start_date: string | null;
  end_date: string | null;
  budget: number | null;
  currency: string;
  content: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface BudgetEntry {
  id: string;
  itinerary_id: string | null;
  user_uuid: string;
  category: string;
  amount: number;
  currency: string;
  description: string | null;
  date: string;
  created_at: string;
}

export interface PackingList {
  id: string;
  itinerary_id: string | null;
  user_uuid: string;
  title: string;
  items: PackingItem[];
  created_at: string;
  updated_at: string;
}

export interface PackingItem {
  id: string;
  name: string;
  checked: boolean;
  category?: string;
}

export interface TravelJournal {
  id: string;
  itinerary_id: string | null;
  user_uuid: string;
  title: string;
  content: string | null;
  location: string | null;
  latitude: number | null;
  longitude: number | null;
  photos: string[];
  date: string;
  created_at: string;
  updated_at: string;
}

export interface SavedDestination {
  id: string;
  user_uuid: string;
  name: string;
  country: string | null;
  description: string | null;
  notes: string | null;
  latitude: number | null;
  longitude: number | null;
  created_at: string;
}

export interface WeatherData {
  temp: number;
  feels_like: number;
  temp_min: number;
  temp_max: number;
  humidity: number;
  description: string;
  icon: string;
  wind_speed: number;
  city: string;
  country: string;
}

export interface NewsArticle {
  uuid: string;
  title: string;
  description: string;
  url: string;
  image_url: string;
  published_at: string;
  source: string;
}

export interface TranslationRequest {
  text: string;
  targetLanguage: string;
  sourceLanguage?: string;
}

export interface ExchangeRate {
  base: string;
  rates: Record<string, number>;
  timestamp: number;
}

export interface SocialPost {
  id: string;
  user_id: string;
  title: string;
  content: string;
  location?: string;
  images: string[];
  likes_count: number;
  created_at: string;
  user?: Profile;
}

export interface PostLike {
  id: string;
  post_id: string;
  user_id: string;
  created_at: string;
}

export interface PostComment {
  id: string;
  post_id: string;
  user_id: string;
  content: string;
  created_at: string;
  user?: Profile;
}

export interface DestinationInfo {
  id: string;
  name: string;
  country?: string;
  description?: string;
  historical_info?: string;
  attractions: Attraction[];
  videos: Video[];
  image_url?: string;
  created_at: string;
}

export interface Attraction {
  name: string;
  description: string;
  type: string;
}

export interface Video {
  title: string;
  url: string;
  thumbnail?: string;
}
