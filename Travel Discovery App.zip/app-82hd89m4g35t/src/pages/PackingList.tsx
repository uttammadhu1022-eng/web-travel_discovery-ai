import React, { useState, useEffect } from 'react';
import { Package, Plus, Trash2, Sparkles, Loader2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import PageMeta from '@/components/common/PageMeta';
import { getPackingLists, createPackingList, updatePackingList, deletePackingList } from '@/db/api';
import { aiAPI } from '@/services/api';
import type { PackingList as PackingListType, PackingItem } from '@/types';

const PackingList: React.FC = () => {
  const [lists, setLists] = useState<PackingListType[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isAIDialogOpen, setIsAIDialogOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [destination, setDestination] = useState('');
  const [days, setDays] = useState('7');
  const [season, setSeason] = useState('');
  const [activities, setActivities] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    loadLists();
  }, []);

  const loadLists = async () => {
    const data = await getPackingLists();
    setLists(data);
  };

  const handleCreateManual = async () => {
    if (!title) {
      toast.error('Please enter a title');
      return;
    }

    await createPackingList({
      title,
      items: [],
    });

    toast.success('Packing list created!');
    setIsDialogOpen(false);
    setTitle('');
    await loadLists();
  };

  const handleGenerateAI = async () => {
    if (!destination || !season) {
      toast.error('Please fill in required fields');
      return;
    }

    setIsGenerating(true);

    try {
      const items = await aiAPI.generatePackingList(destination, Number.parseInt(days), season, activities);
      
      const packingItems: PackingItem[] = items.map((item, index) => ({
        id: `${Date.now()}-${index}`,
        name: item,
        checked: false,
      }));

      await createPackingList({
        title: `${destination} - ${days} Days`,
        items: packingItems,
      });

      toast.success('AI packing list generated!');
      setIsAIDialogOpen(false);
      setDestination('');
      setDays('7');
      setSeason('');
      setActivities('');
      await loadLists();
    } catch (error) {
      console.error('Error generating packing list:', error);
      toast.error('Failed to generate packing list');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleToggleItem = async (listId: string, itemId: string) => {
    const list = lists.find((l) => l.id === listId);
    if (!list) return;

    const updatedItems = list.items.map((item) =>
      item.id === itemId ? { ...item, checked: !item.checked } : item
    );

    await updatePackingList(listId, { items: updatedItems });
    await loadLists();
  };

  const handleAddItem = async (listId: string, itemName: string) => {
    const list = lists.find((l) => l.id === listId);
    if (!list || !itemName.trim()) return;

    const newItem: PackingItem = {
      id: `${Date.now()}`,
      name: itemName,
      checked: false,
    };

    await updatePackingList(listId, { items: [...list.items, newItem] });
    await loadLists();
  };

  const handleDeleteList = async (id: string) => {
    await deletePackingList(id);
    toast.success('Packing list deleted');
    await loadLists();
  };

  return (
    <>
      <PageMeta title="Packing List - Travel Assistant" description="Create and manage packing lists" />
      
      <div className="min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <Package className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Packing List Generator</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Create customized packing lists based on destination, weather, and trip duration
            </p>
          </div>

          <div className="flex justify-between items-center mb-8 gap-4">
            <h2 className="text-2xl font-bold">My Packing Lists</h2>
            <div className="flex gap-2">
              <Dialog open={isAIDialogOpen} onOpenChange={setIsAIDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="secondary">
                    <Sparkles className="mr-2 w-4 h-4" />
                    AI Generate
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Generate with AI</DialogTitle>
                    <DialogDescription>Let AI create a packing list for you</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Destination *</Label>
                      <Input placeholder="e.g., Tokyo, Japan" value={destination} onChange={(e) => setDestination(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label>Number of Days *</Label>
                      <Input type="number" min="1" value={days} onChange={(e) => setDays(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label>Season *</Label>
                      <Input placeholder="e.g., Summer, Winter" value={season} onChange={(e) => setSeason(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label>Activities</Label>
                      <Input placeholder="e.g., Hiking, Beach, City tours" value={activities} onChange={(e) => setActivities(e.target.value)} />
                    </div>
                    <Button onClick={handleGenerateAI} disabled={isGenerating} className="w-full">
                      {isGenerating ? (
                        <>
                          <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <Sparkles className="mr-2 w-4 h-4" />
                          Generate List
                        </>
                      )}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 w-4 h-4" />
                    New List
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create Packing List</DialogTitle>
                    <DialogDescription>Start with an empty list</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>List Title *</Label>
                      <Input placeholder="e.g., Summer Beach Trip" value={title} onChange={(e) => setTitle(e.target.value)} />
                    </div>
                    <Button onClick={handleCreateManual} className="w-full">Create List</Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {lists.map((list) => (
              <PackingListCard
                key={list.id}
                list={list}
                onToggleItem={handleToggleItem}
                onAddItem={handleAddItem}
                onDelete={handleDeleteList}
              />
            ))}
          </div>

          {lists.length === 0 && (
            <div className="text-center py-12">
              <Package className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No packing lists yet. Create your first one!</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

const PackingListCard: React.FC<{
  list: PackingListType;
  onToggleItem: (listId: string, itemId: string) => void;
  onAddItem: (listId: string, itemName: string) => void;
  onDelete: (id: string) => void;
}> = ({ list, onToggleItem, onAddItem, onDelete }) => {
  const [newItem, setNewItem] = useState('');
  const checkedCount = list.items.filter((item) => item.checked).length;
  const progress = list.items.length > 0 ? (checkedCount / list.items.length) * 100 : 0;

  const handleAdd = () => {
    if (newItem.trim()) {
      onAddItem(list.id, newItem);
      setNewItem('');
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <CardTitle className="text-lg">{list.title}</CardTitle>
            <CardDescription>
              {checkedCount} of {list.items.length} packed
            </CardDescription>
          </div>
          <Button variant="ghost" size="icon" onClick={() => onDelete(list.id)}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
        <div className="w-full bg-muted rounded-full h-2 mt-2">
          <div className="bg-primary h-2 rounded-full transition-all" style={{ width: `${progress}%` }} />
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="space-y-2 max-h-[300px] overflow-y-auto">
          {list.items.map((item) => (
            <div key={item.id} className="flex items-center space-x-2">
              <Checkbox
                checked={item.checked}
                onCheckedChange={() => onToggleItem(list.id, item.id)}
              />
              <span className={item.checked ? 'line-through text-muted-foreground' : ''}>
                {item.name}
              </span>
            </div>
          ))}
        </div>
        <div className="flex gap-2 pt-2 border-t">
          <Input
            placeholder="Add item..."
            value={newItem}
            onChange={(e) => setNewItem(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
          />
          <Button size="icon" onClick={handleAdd}>
            <Plus className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default PackingList;
