/*
# Fix User Creation Trigger

Since email verification is disabled, users are created immediately on signup.
The trigger needs to fire on INSERT instead of UPDATE (confirmed_at change).

## Changes
1. Drop old trigger that fires on email confirmation
2. Create new trigger that fires on user INSERT
3. Handle duplicate profile creation gracefully
*/

-- Drop the old trigger
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Update the function to handle duplicates
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
  username_val text;
BEGIN
  -- Check if profile already exists
  IF EXISTS (SELECT 1 FROM profiles WHERE id = NEW.id) THEN
    RETURN NEW;
  END IF;
  
  SELECT COUNT(*) INTO user_count FROM profiles;
  
  -- Extract username from email (before @)
  username_val := split_part(NEW.email, '@', 1);
  
  INSERT INTO profiles (id, email, username, role)
  VALUES (
    NEW.id,
    NEW.email,
    username_val,
    CASE WHEN user_count = 0 THEN 'admin'::user_role ELSE 'user'::user_role END
  )
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
END;
$$;

-- Create trigger that fires on INSERT (user creation)
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();
