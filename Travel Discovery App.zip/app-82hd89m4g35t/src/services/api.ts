import axios from 'axios';
import type { WeatherData, NewsArticle, ExchangeRate } from '@/types';

const APP_ID = import.meta.env.VITE_APP_ID;

const apiClient = axios.create({
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
    'X-App-Id': APP_ID,
  },
});

apiClient.interceptors.response.use(
  (response) => response.data,
  (error) => {
    console.error('API request error:', error);
    if (error.response?.data?.status === 999) {
      throw new Error(error.response.data.msg);
    }
    return Promise.reject(error);
  }
);

export const weatherAPI = {
  getCurrentWeather: async (lat: number, lon: number): Promise<WeatherData | null> => {
    try {
      const response: any = await apiClient.get(
        'https://api-integrations.appmedo.com/app-82hd89m4g35t/api-rY7J6E5obXeL/data/2.5/weather',
        {
          params: {
            lat,
            lon,
            appid: 'ee78c39e8ee2f4843ec15b1507c93b55',
            units: 'metric',
            lang: 'en',
          },
          headers: {
            Accept: 'application/json',
          },
        }
      );

      return {
        temp: response.main.temp,
        feels_like: response.main.feels_like,
        temp_min: response.main.temp_min,
        temp_max: response.main.temp_max,
        humidity: response.main.humidity,
        description: response.weather[0]?.description || '',
        icon: response.weather[0]?.icon || '',
        wind_speed: response.wind.speed,
        city: response.name,
        country: response.sys.country,
      };
    } catch (error) {
      console.error('Error fetching weather:', error);
      return null;
    }
  },
};

export const newsAPI = {
  getNews: async (query?: string, limit = 10): Promise<NewsArticle[]> => {
    try {
      const response: any = await apiClient.get(
        'https://api-integrations.appmedo.com/app-82hd89m4g35t/api-AalZ7GMdogGL/v1/news/all',
        {
          params: {
            search: query,
            limit,
            language: 'en',
            sort: 'published_at',
          },
          headers: {
            Accept: 'application/json',
          },
        }
      );

      return Array.isArray(response.data) ? response.data : [];
    } catch (error) {
      console.error('Error fetching news:', error);
      return [];
    }
  },
};

export const translationAPI = {
  translate: async (text: string, targetLang: string, sourceLang?: string): Promise<string> => {
    try {
      const response: any = await apiClient.post(
        'https://api-integrations.appmedo.com/app-82hd89m4g35t/api-eLMl28BvNej9/language/translate/v2',
        {
          q: text,
          target: targetLang,
          source: sourceLang,
          format: 'text',
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'dummy-key',
          },
        }
      );

      return response.data?.translations?.[0]?.translatedText || text;
    } catch (error) {
      console.error('Error translating text:', error);
      return text;
    }
  },
};

export const exchangeRateAPI = {
  getRates: async (baseCurrency = 'USD'): Promise<ExchangeRate | null> => {
    try {
      const response: any = await apiClient.get(
        `https://api-integrations.appmedo.com/app-82hd89m4g35t/api-Xa6JxgR5Jrda/v6/8192723d20263507156f9754/latest/${baseCurrency}`,
        {
          headers: {
            Accept: 'application/json',
          },
        }
      );

      if (response.result === 'success') {
        return {
          base: response.base_code,
          rates: response.conversion_rates,
          timestamp: response.time_last_update_unix,
        };
      }

      return null;
    } catch (error) {
      console.error('Error fetching exchange rates:', error);
      return null;
    }
  },
};

export const aiAPI = {
  generateItinerary: async (destination: string, days: number, budget: number, preferences: string): Promise<string> => {
    try {
      const prompt = `Create a detailed ${days}-day travel itinerary for ${destination} with a budget of $${budget}. 
Preferences: ${preferences}

Please provide:
1. Daily schedule with activities
2. Recommended restaurants and local cuisine
3. Transportation tips
4. Budget breakdown
5. Local tips and cultural insights

Format the response in a clear, organized manner.`;

      const url = 'https://api-integrations.appmedo.com/app-82hd89m4g35t/api-rLob8RdzAOl9/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse';
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-App-Id': APP_ID,
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: prompt }],
            },
          ],
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate itinerary');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let result = '';

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const jsonData = JSON.parse(line.slice(6));
                const text = jsonData.candidates?.[0]?.content?.parts?.[0]?.text;
                if (text) {
                  result += text;
                }
              } catch (e) {
                console.error('Error parsing chunk:', e);
              }
            }
          }
        }
      }

      return result || 'Unable to generate itinerary. Please try again.';
    } catch (error) {
      console.error('Error generating itinerary:', error);
      return 'Unable to generate itinerary. Please try again.';
    }
  },

  generatePackingList: async (destination: string, days: number, season: string, activities: string): Promise<string[]> => {
    try {
      const prompt = `Generate a comprehensive packing list for a ${days}-day trip to ${destination} during ${season}.
Activities planned: ${activities}

Please provide a categorized list of items to pack. Return ONLY a JSON array of strings, no other text.
Example format: ["Passport", "Travel insurance documents", "Comfortable walking shoes", ...]`;

      const url = 'https://api-integrations.appmedo.com/app-82hd89m4g35t/api-rLob8RdzAOl9/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse';
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-App-Id': APP_ID,
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: prompt }],
            },
          ],
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate packing list');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let result = '';

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const jsonData = JSON.parse(line.slice(6));
                const text = jsonData.candidates?.[0]?.content?.parts?.[0]?.text;
                if (text) {
                  result += text;
                }
              } catch (e) {
                console.error('Error parsing chunk:', e);
              }
            }
          }
        }
      }

      try {
        const jsonMatch = result.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          return JSON.parse(jsonMatch[0]);
        }
      } catch (e) {
        console.error('Error parsing packing list:', e);
      }

      return [
        'Passport',
        'Travel insurance',
        'Comfortable shoes',
        'Weather-appropriate clothing',
        'Toiletries',
        'Medications',
        'Phone charger',
        'Camera',
        'Travel adapter',
        'First aid kit',
      ];
    } catch (error) {
      console.error('Error generating packing list:', error);
      return [
        'Passport',
        'Travel insurance',
        'Comfortable shoes',
        'Weather-appropriate clothing',
        'Toiletries',
      ];
    }
  },

  generateContent: async (prompt: string): Promise<string> => {
    try {
      const url = 'https://api-integrations.appmedo.com/app-82hd89m4g35t/api-rLob8RdzAOl9/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse';
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-App-Id': APP_ID,
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: prompt }],
            },
          ],
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate content');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let result = '';

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const jsonData = JSON.parse(line.slice(6));
                const text = jsonData.candidates?.[0]?.content?.parts?.[0]?.text;
                if (text) {
                  result += text;
                }
              } catch (e) {
                console.error('Error parsing chunk:', e);
              }
            }
          }
        }
      }

      return result || 'No content generated';
    } catch (error) {
      console.error('Error generating content:', error);
      throw error;
    }
  },
};

export default {
  weather: weatherAPI,
  news: newsAPI,
  translation: translationAPI,
  exchangeRate: exchangeRateAPI,
  ai: aiAPI,
};
