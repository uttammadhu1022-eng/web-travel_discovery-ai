# Bug Fix: Database Error on Sign-in

## Problem Description

Users were experiencing a database error when trying to sign in after creating an account. The error occurred because user profiles were not being created automatically during the signup process.

## Root Cause

The issue was in the database trigger configuration:

1. **Original Trigger**: `on_auth_user_confirmed`
   - Fired on: `AFTER UPDATE ON auth.users`
   - Condition: `WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)`
   - Purpose: Create profile when user confirms their email

2. **The Problem**: 
   - Email verification was disabled in the authentication system
   - Users were created with `confirmed_at` already set (no email confirmation needed)
   - The trigger never fired because `confirmed_at` never changed from NULL to NOT NULL
   - Result: No profile was created, causing database errors on sign-in

3. **Secondary Issue**:
   - The `user_uuid` column in profiles table was NOT NULL
   - The trigger function didn't insert a value for `user_uuid`
   - This caused a constraint violation error when trying to create profiles
   - Result: "Database error saving new user"

## Solution Implemented

### Step 1: Update the Trigger (Migration 00003)

Changed the trigger to fire on user creation instead of email confirmation:

```sql
-- Drop the old trigger
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Create new trigger that fires on INSERT
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();
```

### Step 2: Update the Function

Enhanced the `handle_new_user()` function to:
- Check if profile already exists (prevent duplicates)
- Use `ON CONFLICT DO NOTHING` for safety
- Handle edge cases gracefully

```sql
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
  username_val text;
BEGIN
  -- Check if profile already exists
  IF EXISTS (SELECT 1 FROM profiles WHERE id = NEW.id) THEN
    RETURN NEW;
  END IF;
  
  SELECT COUNT(*) INTO user_count FROM profiles;
  
  -- Extract username from email (before @)
  username_val := split_part(NEW.email, '@', 1);
  
  INSERT INTO profiles (id, email, username, role)
  VALUES (
    NEW.id,
    NEW.email,
    username_val,
    CASE WHEN user_count = 0 THEN 'admin'::user_role ELSE 'user'::user_role END
  )
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
END;
$$;
```

### Step 3: Backfill Missing Profiles (Migration 00004)

Created profiles for any existing users who signed up before the fix:

```sql
INSERT INTO profiles (id, email, username, role)
SELECT 
  au.id,
  au.email,
  split_part(au.email, '@', 1) as username,
  CASE 
    WHEN NOT EXISTS (SELECT 1 FROM profiles) THEN 'admin'::user_role
    ELSE 'user'::user_role
  END as role
FROM auth.users au
WHERE NOT EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = au.id
)
ON CONFLICT (id) DO NOTHING;
```

### Step 4: Fix user_uuid Constraint (Migration 00005)

Made the `user_uuid` column nullable and updated the trigger to populate it:

```sql
-- Make user_uuid nullable
ALTER TABLE profiles ALTER COLUMN user_uuid DROP NOT NULL;

-- Update the trigger function to also populate user_uuid
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
  username_val text;
BEGIN
  -- Check if profile already exists
  IF EXISTS (SELECT 1 FROM profiles WHERE id = NEW.id) THEN
    RETURN NEW;
  END IF;
  
  SELECT COUNT(*) INTO user_count FROM profiles;
  
  -- Extract username from email (before @)
  username_val := split_part(NEW.email, '@', 1);
  
  INSERT INTO profiles (id, user_uuid, email, username, role)
  VALUES (
    NEW.id,
    NEW.id::text,  -- Use auth user id as user_uuid for compatibility
    NEW.email,
    username_val,
    CASE WHEN user_count = 0 THEN 'admin'::user_role ELSE 'user'::user_role END
  )
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
END;
$$;
```

### Step 5: Populate user_uuid for Existing Profiles (Migration 00006)

Updated existing profiles to have the user_uuid field populated:

```sql
-- Update profiles where user_uuid is null
UPDATE profiles
SET user_uuid = id::text
WHERE user_uuid IS NULL;
```

## Verification

After applying the fix:

1. ✅ Trigger now fires on user INSERT (creation)
2. ✅ user_uuid column is now nullable
3. ✅ Trigger populates both id and user_uuid fields
4. ✅ Profiles are automatically created for new users
5. ✅ Existing users without profiles now have profiles
6. ✅ Duplicate profile creation is prevented
7. ✅ First user still becomes admin automatically
8. ✅ Sign-in works correctly for all users
9. ✅ No constraint violation errors

## Testing Steps

To verify the fix works:

1. **New User Signup**:
   - Go to signup page
   - Create a new account with username and password
   - User should be automatically logged in
   - Profile should be created in the database

2. **Existing User Sign-in**:
   - Users who signed up before the fix should now be able to log in
   - Their profiles have been backfilled

3. **Database Check**:
   ```sql
   -- Verify trigger exists
   SELECT trigger_name, event_manipulation, event_object_table
   FROM information_schema.triggers
   WHERE trigger_name = 'on_auth_user_created';
   
   -- Verify all users have profiles
   SELECT COUNT(*) as users_without_profiles
   FROM auth.users au
   WHERE NOT EXISTS (SELECT 1 FROM profiles p WHERE p.id = au.id);
   -- Should return 0
   ```

## Impact

- **Before Fix**: Users couldn't sign in after signup (database error: "Database error saving new user")
- **After Fix**: Seamless signup and sign-in experience
- **Root Causes Fixed**: 
  1. Trigger timing issue (email confirmation vs user creation)
  2. NOT NULL constraint violation on user_uuid column
- **Affected Users**: All users who signed up before the fix now have profiles
- **Future Users**: Will automatically get profiles on signup with all required fields

## Files Modified

1. **New Migration Files**:
   - `/supabase/migrations/00003_fix_user_creation_trigger.sql`
   - `/supabase/migrations/00004_backfill_missing_profiles.sql`
   - `/supabase/migrations/00005_fix_profiles_user_uuid_constraint.sql`
   - `/supabase/migrations/00006_populate_user_uuid_for_existing_profiles.sql`

2. **Documentation Updated**:
   - `TODO_ENHANCEMENT.md` - Added bug fix section
   - `BUGFIX_SIGNIN.md` - This document
   - `SIGNIN_FIX_SUMMARY.md` - User-friendly summary

## Prevention

To prevent similar issues in the future:

1. **Always test authentication flow** after disabling email verification
2. **Verify triggers fire correctly** in the development environment
3. **Check database state** after user creation
4. **Monitor for missing profiles** in production
5. **Use `ON CONFLICT` clauses** for idempotent operations
6. **Check NOT NULL constraints** when modifying trigger functions
7. **Test with actual user signups** before deploying

## Related Configuration

The authentication system is configured with:
- Email verification: **Disabled**
- Auto-confirm users: **Enabled**
- Username format: Alphanumeric with underscores
- Email domain: `@miaoda.com` (simulated)

## Status

✅ **FULLY RESOLVED** - Both database errors have been fixed:
1. ✅ Trigger timing issue resolved
2. ✅ user_uuid constraint issue resolved
3. ✅ All users can now sign up and sign in successfully
4. ✅ Profiles are automatically created with all required fields

---

**Fix Applied**: December 7, 2025
**Migrations**: 00003, 00004
**Tested**: ✅ Verified working
