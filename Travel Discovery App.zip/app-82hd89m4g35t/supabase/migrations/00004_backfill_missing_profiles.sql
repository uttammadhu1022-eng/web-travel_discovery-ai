/*
# Backfill Missing Profiles

Create profiles for any existing auth.users that don't have a profile yet.
This handles users created before the trigger was fixed.
*/

-- Create profiles for existing users without profiles
INSERT INTO profiles (id, email, username, role)
SELECT 
  au.id,
  au.email,
  split_part(au.email, '@', 1) as username,
  CASE 
    WHEN NOT EXISTS (SELECT 1 FROM profiles) THEN 'admin'::user_role
    ELSE 'user'::user_role
  END as role
FROM auth.users au
WHERE NOT EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = au.id
)
ON CONFLICT (id) DO NOTHING;
