# Google Maps Integration Setup Guide

## Overview
The Travel Assistant's Interactive Travel Map now uses Google Maps for enhanced mapping capabilities, including location search, accurate geocoding, and better map quality.

## Required APIs
To use the Interactive Travel Map feature, you need to enable the following Google Maps APIs:

1. **Maps JavaScript API** - For displaying the interactive map
2. **Places API** - For location search and autocomplete
3. **Geocoding API** - For converting addresses to coordinates

## Setup Instructions

### Step 1: Create a Google Cloud Project
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Note your project name for reference

### Step 2: Enable Required APIs
1. Navigate to **APIs & Services** > **Library**
2. Search for and enable each of the following:
   - Maps JavaScript API
   - Places API
   - Geocoding API

### Step 3: Create an API Key
1. Go to **APIs & Services** > **Credentials**
2. Click **Create Credentials** > **API Key**
3. Copy the generated API key
4. (Recommended) Click **Restrict Key** to add security restrictions:
   - **Application restrictions**: Set to "HTTP referrers" for web apps
   - **API restrictions**: Select only the APIs listed above

### Step 4: Configure Your Application
1. Open the `.env` file in your project root
2. Add your API key:
   ```
   VITE_GOOGLE_MAPS_API_KEY=your_actual_api_key_here
   ```
3. Save the file and restart your development server

## Features Enabled

### 1. Interactive Google Maps Display
- High-quality map rendering with satellite and terrain views
- Smooth zoom and pan controls
- Custom markers for route points

### 2. Location Search
- Real-time location search powered by Google Places
- Autocomplete suggestions as you type
- Automatic coordinate extraction

### 3. Route Visualization
- Visual route lines connecting destinations
- Numbered markers showing stop order
- Info windows with location details

### 4. Manual Entry Fallback
- Option to manually enter coordinates if needed
- Supports both search and manual input methods

## Usage

### Adding Destinations
1. Click the **Add Destination** button
2. **Option A - Search**: Start typing a location name in the search box
   - Select from autocomplete suggestions
   - Location is automatically added to your route
3. **Option B - Manual**: Scroll down to "Or enter manually"
   - Enter place name, latitude, and longitude
   - Click "Add Manually"

### Viewing Your Route
- All destinations appear as numbered markers on the map
- A blue line connects destinations in order
- Click any marker to see location details
- Map automatically adjusts to show all points

### Managing Destinations
- Remove destinations using the trash icon in the route list
- Reorder by removing and re-adding in desired sequence
- Filter by category using the category selector

## Troubleshooting

### Map Not Loading
- **Check API Key**: Ensure `VITE_GOOGLE_MAPS_API_KEY` is set in `.env`
- **Verify APIs**: Confirm all three APIs are enabled in Google Cloud Console
- **Check Restrictions**: If using API restrictions, ensure your domain is allowed
- **Browser Console**: Check for error messages in browser developer tools

### Search Not Working
- **Places API**: Verify Places API is enabled
- **API Key**: Ensure the API key has access to Places API
- **Network**: Check your internet connection

### Billing Concerns
- Google Maps offers a generous free tier ($200 credit per month)
- Most personal projects stay within free limits
- Set up billing alerts in Google Cloud Console to monitor usage
- Consider adding usage quotas to prevent unexpected charges

## Cost Optimization Tips

1. **API Restrictions**: Restrict your API key to specific domains
2. **Caching**: The app caches map data to reduce API calls
3. **Lazy Loading**: Map components load only when needed
4. **Monitoring**: Regularly check usage in Google Cloud Console

## Security Best Practices

1. **Never commit API keys**: The `.env` file is in `.gitignore`
2. **Use restrictions**: Always restrict API keys in production
3. **Rotate keys**: Periodically generate new API keys
4. **Monitor usage**: Set up alerts for unusual activity

## Alternative: Development Without API Key

If you don't have a Google Maps API key, the map will display a friendly message explaining the requirement. You can still:
- Use the manual coordinate entry feature
- View the route list and manage destinations
- Access all other Travel Assistant features

## Support Resources

- [Google Maps Platform Documentation](https://developers.google.com/maps/documentation)
- [API Key Best Practices](https://developers.google.com/maps/api-security-best-practices)
- [Pricing Calculator](https://mapsplatform.google.com/pricing/)
- [Google Cloud Console](https://console.cloud.google.com/)

## Questions?

For issues specific to this application, check the browser console for error messages. For Google Maps API issues, refer to the official documentation linked above.
