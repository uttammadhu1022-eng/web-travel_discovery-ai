# Troubleshooting Guide - Travel Assistant

## Authentication Issues

### "Database error saving new user"
**Status**: ✅ FIXED

This error has been resolved. If you still see it:
1. Refresh the page
2. Clear browser cache
3. Try signing up again

**Root Cause**: Database trigger wasn't firing + constraint violation
**Fix Applied**: Migrations 00003-00006

---

## Common Issues & Solutions

### Cannot Sign Up

**Symptom**: Error message when creating account

**Possible Causes**:
1. Username already taken
2. Invalid username format
3. Password too short

**Solutions**:
- Use unique username (letters, numbers, underscores only)
- Password must be at least 6 characters
- Try a different username

---

### Cannot Sign In

**Symptom**: "Invalid credentials" or similar error

**Possible Causes**:
1. Wrong username or password
2. Account doesn't exist
3. Browser cache issues

**Solutions**:
- Double-check username and password
- Usernames are case-sensitive
- Try clearing browser cache
- If new user, sign up first

---

### Profile Not Loading

**Symptom**: Blank profile page or missing data

**Possible Causes**:
1. Profile not created (should be automatic now)
2. Network issues
3. Browser cache

**Solutions**:
- Refresh the page
- Sign out and sign in again
- Clear browser cache
- Check internet connection

---

### Onboarding Page Issues

**Symptom**: Cannot save travel interests or bio

**Possible Causes**:
1. Network issues
2. Invalid data format
3. Database connection issues

**Solutions**:
- Check internet connection
- Try selecting different interests
- Refresh page and try again
- Bio should be plain text

---

## Database Verification

If you're a developer and want to verify the database state:

### Check Trigger Status
```sql
SELECT tgname, tgenabled 
FROM pg_trigger 
WHERE tgname = 'on_auth_user_created';
```
Expected: 1 row, tgenabled = 'O' (enabled)

### Check Profiles Table
```sql
SELECT column_name, is_nullable 
FROM information_schema.columns 
WHERE table_name = 'profiles' 
  AND column_name IN ('id', 'user_uuid', 'role');
```
Expected:
- id: NOT NULL
- user_uuid: NULLABLE
- role: NOT NULL

### Check User Profiles
```sql
SELECT COUNT(*) as total_users,
       COUNT(CASE WHEN role = 'admin' THEN 1 END) as admins,
       COUNT(CASE WHEN role = 'user' THEN 1 END) as users
FROM profiles;
```

### Verify Trigger Function
```sql
SELECT proname, prosrc 
FROM pg_proc 
WHERE proname = 'handle_new_user';
```
Should include: INSERT INTO profiles (id, user_uuid, email, username, role)

---

## Quick Fixes

### Clear Browser Cache
1. Press `Ctrl+Shift+Delete` (Windows/Linux) or `Cmd+Shift+Delete` (Mac)
2. Select "Cached images and files"
3. Click "Clear data"
4. Refresh the page

### Force Refresh
- Windows/Linux: `Ctrl+F5`
- Mac: `Cmd+Shift+R`

### Sign Out and Back In
1. Click profile icon
2. Click "Sign Out"
3. Go to login page
4. Sign in again

---

## Error Messages

### "Invalid credentials"
- Username or password is incorrect
- Try resetting password (if feature available)
- Verify username spelling

### "Username already exists"
- Choose a different username
- Usernames must be unique

### "Password too short"
- Use at least 6 characters
- Include letters and numbers for security

### "Network error"
- Check internet connection
- Try refreshing the page
- Wait a moment and try again

---

## Getting Help

If none of these solutions work:

1. **Check Documentation**:
   - `SIGNIN_FIX_SUMMARY.md` - User-friendly guide
   - `BUGFIX_SIGNIN.md` - Technical details
   - `FIX_COMPLETE.md` - Complete fix documentation

2. **Verify System Status**:
   - All migrations applied: ✅
   - Trigger active: ✅
   - Database ready: ✅

3. **Try Basic Steps**:
   - Refresh page
   - Clear cache
   - Try different browser
   - Check internet connection

---

## System Status

Current Status: ✅ **ALL SYSTEMS OPERATIONAL**

- Authentication: ✅ Working
- User Signup: ✅ Working
- User Sign In: ✅ Working
- Profile Creation: ✅ Automatic
- Database: ✅ Healthy
- Triggers: ✅ Active

Last Updated: December 7, 2025

---

## Developer Notes

### Recent Fixes Applied
1. Fixed trigger timing (00003)
2. Backfilled missing profiles (00004)
3. Fixed user_uuid constraint (00005)
4. Populated user_uuid for existing profiles (00006)

### Key Changes
- Trigger now fires on INSERT instead of UPDATE
- user_uuid is now nullable
- Trigger populates both id and user_uuid
- First user automatically becomes admin

### Testing Checklist
- [x] New user signup works
- [x] Existing user sign in works
- [x] Profile creation is automatic
- [x] No constraint violations
- [x] No lint errors
- [x] All migrations applied

---

**System Ready**: ✅ Production  
**Last Verified**: December 7, 2025  
**Status**: Fully Operational
