/*
# Add Authentication and Social Features

## 1. Updates to Profiles Table
- Add user interests and preferences
- Add authentication support
- Update to reference auth.users

## 2. New Tables
- `social_posts`: User-generated travel experiences with images
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `title` (text)
  - `content` (text)
  - `location` (text)
  - `images` (text array)
  - `likes_count` (integer, default 0)
  - `created_at` (timestamptz)

- `post_likes`: Track user likes on posts
  - `id` (uuid, primary key)
  - `post_id` (uuid, references social_posts)
  - `user_id` (uuid, references profiles)
  - `created_at` (timestamptz)

- `post_comments`: Comments on social posts
  - `id` (uuid, primary key)
  - `post_id` (uuid, references social_posts)
  - `user_id` (uuid, references profiles)
  - `content` (text)
  - `created_at` (timestamptz)

- `destinations_info`: Historical and attraction information
  - `id` (uuid, primary key)
  - `name` (text)
  - `country` (text)
  - `description` (text)
  - `historical_info` (text)
  - `attractions` (jsonb)
  - `videos` (jsonb array)
  - `created_at` (timestamptz)

## 3. User Role System
- Create user_role ENUM type
- Add role column to profiles
- First user becomes admin

## 4. Security
- Enable RLS on all new tables
- Admins have full access
- Users can create/edit their own content
- All users can view public content

## 5. Trigger for Auto-sync Users
- Automatically create profile when user confirms email
*/

-- Update profiles table for auth
ALTER TABLE profiles DROP COLUMN IF EXISTS user_id;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS username text UNIQUE;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS travel_interests text[];
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS bio text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS avatar_url text;

-- Create user role enum if not exists
DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('user', 'admin');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- Add role column if not exists
DO $$ BEGIN
  ALTER TABLE profiles ADD COLUMN role user_role DEFAULT 'user'::user_role NOT NULL;
EXCEPTION
  WHEN duplicate_column THEN null;
END $$;

-- Create social_posts table
CREATE TABLE IF NOT EXISTS social_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL,
  location text,
  images text[] DEFAULT '{}',
  likes_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create post_likes table
CREATE TABLE IF NOT EXISTS post_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES social_posts(id) ON DELETE CASCADE,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(post_id, user_id)
);

-- Create post_comments table
CREATE TABLE IF NOT EXISTS post_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES social_posts(id) ON DELETE CASCADE,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create destinations_info table
CREATE TABLE IF NOT EXISTS destinations_info (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  country text,
  description text,
  historical_info text,
  attractions jsonb DEFAULT '[]',
  videos jsonb DEFAULT '[]',
  image_url text,
  created_at timestamptz DEFAULT now()
);

-- Create storage bucket for social post images
INSERT INTO storage.buckets (id, name, public)
VALUES ('app-82hd89m4g35t_social_images', 'app-82hd89m4g35t_social_images', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for social images
CREATE POLICY "Anyone can view social images"
ON storage.objects FOR SELECT
USING (bucket_id = 'app-82hd89m4g35t_social_images');

CREATE POLICY "Authenticated users can upload social images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'app-82hd89m4g35t_social_images');

CREATE POLICY "Users can update their own images"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'app-82hd89m4g35t_social_images');

CREATE POLICY "Users can delete their own images"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'app-82hd89m4g35t_social_images');

-- Enable RLS
ALTER TABLE social_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE destinations_info ENABLE ROW LEVEL SECURITY;

-- Helper function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- Policies for social_posts
CREATE POLICY "Anyone can view posts" ON social_posts
  FOR SELECT USING (true);

CREATE POLICY "Authenticated users can create posts" ON social_posts
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own posts" ON social_posts
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own posts" ON social_posts
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins have full access to posts" ON social_posts
  FOR ALL TO authenticated
  USING (is_admin(auth.uid()));

-- Policies for post_likes
CREATE POLICY "Anyone can view likes" ON post_likes
  FOR SELECT USING (true);

CREATE POLICY "Authenticated users can like posts" ON post_likes
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can unlike posts" ON post_likes
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- Policies for post_comments
CREATE POLICY "Anyone can view comments" ON post_comments
  FOR SELECT USING (true);

CREATE POLICY "Authenticated users can comment" ON post_comments
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own comments" ON post_comments
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own comments" ON post_comments
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- Policies for destinations_info
CREATE POLICY "Anyone can view destinations" ON destinations_info
  FOR SELECT USING (true);

CREATE POLICY "Admins can manage destinations" ON destinations_info
  FOR ALL TO authenticated
  USING (is_admin(auth.uid()));

-- Update profiles policies
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile without changing role" ON profiles;
DROP POLICY IF EXISTS "Admins have full access" ON profiles;

CREATE POLICY "Anyone can view profiles" ON profiles
  FOR SELECT USING (true);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id AND (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid())));

CREATE POLICY "Admins have full access to profiles" ON profiles
  FOR ALL TO authenticated
  USING (is_admin(auth.uid()));

-- Function to handle new user registration
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
  username_val text;
BEGIN
  SELECT COUNT(*) INTO user_count FROM profiles;
  
  -- Extract username from email (before @)
  username_val := split_part(NEW.email, '@', 1);
  
  INSERT INTO profiles (id, email, username, role)
  VALUES (
    NEW.id,
    NEW.email,
    username_val,
    CASE WHEN user_count = 0 THEN 'admin'::user_role ELSE 'user'::user_role END
  );
  RETURN NEW;
END;
$$;

-- Create trigger for new user
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION handle_new_user();

-- Function to increment likes count
CREATE OR REPLACE FUNCTION increment_post_likes()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE social_posts
  SET likes_count = likes_count + 1
  WHERE id = NEW.post_id;
  RETURN NEW;
END;
$$;

-- Function to decrement likes count
CREATE OR REPLACE FUNCTION decrement_post_likes()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE social_posts
  SET likes_count = likes_count - 1
  WHERE id = OLD.post_id;
  RETURN OLD;
END;
$$;

-- Triggers for likes count
DROP TRIGGER IF EXISTS on_like_added ON post_likes;
CREATE TRIGGER on_like_added
  AFTER INSERT ON post_likes
  FOR EACH ROW
  EXECUTE FUNCTION increment_post_likes();

DROP TRIGGER IF EXISTS on_like_removed ON post_likes;
CREATE TRIGGER on_like_removed
  AFTER DELETE ON post_likes
  FOR EACH ROW
  EXECUTE FUNCTION decrement_post_likes();