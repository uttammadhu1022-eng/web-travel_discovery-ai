import React, { useState, useEffect } from 'react';
import { Users, Plus, Heart, MessageCircle, Loader2, Upload, X, Edit2, Trash2, MoreVertical } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { toast } from 'sonner';
import PageMeta from '@/components/common/PageMeta';
import { supabase } from '@/db/supabase';
import TranslateButton from '@/components/community/TranslateButton';
import { getLanguageName } from '@/services/translationService';
import UserProfileDialog from '@/components/profile/UserProfileDialog';
import type { SocialPost } from '@/types';

interface PostTranslation {
  translatedText: string;
  sourceLanguage: string;
  targetLanguage: string;
}

const Community: React.FC = () => {
  const [posts, setPosts] = useState<SocialPost[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [location, setLocation] = useState('');
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [translations, setTranslations] = useState<Record<string, PostTranslation>>({});
  const [editingPost, setEditingPost] = useState<SocialPost | null>(null);
  const [deletePostId, setDeletePostId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [viewingUserId, setViewingUserId] = useState<string | null>(null);
  const [isProfileDialogOpen, setIsProfileDialogOpen] = useState(false);

  useEffect(() => {
    loadPosts();
    getCurrentUser();
  }, []);

  const getCurrentUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    setCurrentUser(user?.id || null);
  };

  const loadPosts = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('social_posts')
        .select(`
          *,
          user:profiles(id, username, avatar_url)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      console.error('Error loading posts:', error);
      toast.error('Failed to load posts');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    // Validate file types
    const validFiles = files.filter(file => {
      if (!file.type.startsWith('image/')) {
        toast.error(`${file.name} is not an image file`);
        return false;
      }
      return true;
    });

    setSelectedFiles(prev => [...prev, ...validFiles].slice(0, 4)); // Max 4 images
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const compressImage = async (file: File): Promise<File> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;

          // Resize if larger than 1080p
          const maxDimension = 1080;
          if (width > maxDimension || height > maxDimension) {
            if (width > height) {
              height = (height / width) * maxDimension;
              width = maxDimension;
            } else {
              width = (width / height) * maxDimension;
              height = maxDimension;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);

          canvas.toBlob(
            (blob) => {
              if (blob) {
                const compressedFile = new File([blob], file.name.replace(/\.[^/.]+$/, '.webp'), {
                  type: 'image/webp',
                });
                resolve(compressedFile);
              } else {
                resolve(file);
              }
            },
            'image/webp',
            0.8
          );
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const uploadImages = async (files: File[]): Promise<string[]> => {
    const uploadedUrls: string[] = [];

    for (const file of files) {
      try {
        let fileToUpload = file;
        
        // Compress if larger than 1MB
        if (file.size > 1024 * 1024) {
          fileToUpload = await compressImage(file);
          toast.info(`Compressed ${file.name} to ${(fileToUpload.size / 1024).toFixed(0)}KB`);
        }

        const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.webp`;
        const { data, error } = await supabase.storage
          .from('app-82hd89m4g35t_social_images')
          .upload(fileName, fileToUpload);

        if (error) throw error;

        const { data: { publicUrl } } = supabase.storage
          .from('app-82hd89m4g35t_social_images')
          .getPublicUrl(data.path);

        uploadedUrls.push(publicUrl);
      } catch (error) {
        console.error('Error uploading image:', error);
        toast.error(`Failed to upload ${file.name}`);
      }
    }

    return uploadedUrls;
  };

  const handleCreatePost = async () => {
    if (!title || !content) {
      toast.error('Please fill in title and content');
      return;
    }

    if (!currentUser) {
      toast.error('Please log in to create a post');
      return;
    }

    setIsSubmitting(true);

    try {
      let imageUrls: string[] = [];
      
      if (selectedFiles.length > 0) {
        imageUrls = await uploadImages(selectedFiles);
      }

      const { error } = await supabase
        .from('social_posts')
        .insert({
          user_id: currentUser,
          title,
          content,
          location,
          images: imageUrls,
        });

      if (error) throw error;

      toast.success('Post created successfully!');
      setIsDialogOpen(false);
      setTitle('');
      setContent('');
      setLocation('');
      setSelectedFiles([]);
      await loadPosts();
    } catch (error) {
      console.error('Error creating post:', error);
      toast.error('Failed to create post');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLike = async (postId: string) => {
    if (!currentUser) {
      toast.error('Please log in to like posts');
      return;
    }

    try {
      // Check if already liked
      const { data: existingLike } = await supabase
        .from('post_likes')
        .select('id')
        .eq('post_id', postId)
        .eq('user_id', currentUser)
        .single();

      if (existingLike) {
        // Unlike
        await supabase
          .from('post_likes')
          .delete()
          .eq('post_id', postId)
          .eq('user_id', currentUser);
      } else {
        // Like
        await supabase
          .from('post_likes')
          .insert({ post_id: postId, user_id: currentUser });
      }

      await loadPosts();
    } catch (error) {
      console.error('Error toggling like:', error);
    }
  };

  const handleTranslated = (postId: string, translatedText: string, sourceLanguage: string, targetLanguage: string) => {
    setTranslations(prev => ({
      ...prev,
      [postId]: { translatedText, sourceLanguage, targetLanguage }
    }));
  };

  const handleResetTranslation = (postId: string) => {
    setTranslations(prev => {
      const newTranslations = { ...prev };
      delete newTranslations[postId];
      return newTranslations;
    });
  };

  const handleEditPost = (post: SocialPost) => {
    setEditingPost(post);
    setTitle(post.title);
    setContent(post.content);
    setLocation(post.location || '');
    setSelectedFiles([]);
    setIsDialogOpen(true);
  };

  const handleUpdatePost = async () => {
    if (!title || !content) {
      toast.error('Please fill in title and content');
      return;
    }

    if (!editingPost) return;

    setIsSubmitting(true);

    try {
      let imageUrls: string[] = editingPost.images || [];
      
      if (selectedFiles.length > 0) {
        const newImageUrls = await uploadImages(selectedFiles);
        imageUrls = [...imageUrls, ...newImageUrls];
      }

      const { error } = await supabase
        .from('social_posts')
        .update({
          title,
          content,
          location,
          images: imageUrls,
        })
        .eq('id', editingPost.id);

      if (error) throw error;

      toast.success('Post updated successfully!');
      setIsDialogOpen(false);
      setEditingPost(null);
      setTitle('');
      setContent('');
      setLocation('');
      setSelectedFiles([]);
      await loadPosts();
    } catch (error) {
      console.error('Error updating post:', error);
      toast.error('Failed to update post');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeletePost = async () => {
    if (!deletePostId) return;

    setIsDeleting(true);

    try {
      const { error } = await supabase
        .from('social_posts')
        .delete()
        .eq('id', deletePostId);

      if (error) throw error;

      toast.success('Post deleted successfully!');
      setDeletePostId(null);
      await loadPosts();
    } catch (error) {
      console.error('Error deleting post:', error);
      toast.error('Failed to delete post');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleDialogClose = (open: boolean) => {
    setIsDialogOpen(open);
    if (!open) {
      setEditingPost(null);
      setTitle('');
      setContent('');
      setLocation('');
      setSelectedFiles([]);
    }
  };

  const handleViewProfile = (userId: string) => {
    setViewingUserId(userId);
    setIsProfileDialogOpen(true);
  };

  return (
    <>
      <PageMeta title="Community - Travel Discovery" description="Share and discover travel experiences" />
      
      <div className="min-h-screen py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <Users className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Travel Community</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Share your travel experiences and connect with fellow travelers
            </p>
          </div>

          <div className="mb-8">
            <Dialog open={isDialogOpen} onOpenChange={handleDialogClose}>
              <DialogTrigger asChild>
                <Button size="lg" className="w-full">
                  <Plus className="mr-2 w-5 h-5" />
                  Share Your Experience
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>{editingPost ? 'Edit Post' : 'Share Your Travel Experience'}</DialogTitle>
                  <DialogDescription>
                    {editingPost ? 'Update your travel story' : 'Tell the community about your adventure'}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Title *</Label>
                    <Input
                      placeholder="e.g., Amazing sunset at Santorini"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Location</Label>
                    <Input
                      placeholder="e.g., Santorini, Greece"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Your Story *</Label>
                    <Textarea
                      placeholder="Share your experience, tips, and memories..."
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      rows={6}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Photos (Max 4)</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handleFileSelect}
                        className="hidden"
                        id="file-upload"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => document.getElementById('file-upload')?.click()}
                        disabled={selectedFiles.length >= 4}
                      >
                        <Upload className="mr-2 w-4 h-4" />
                        Upload Photos
                      </Button>
                      <span className="text-sm text-muted-foreground">
                        {selectedFiles.length}/4 selected
                      </span>
                    </div>
                    {selectedFiles.length > 0 && (
                      <div className="grid grid-cols-4 gap-2 mt-2">
                        {selectedFiles.map((file, index) => (
                          <div key={index} className="relative">
                            <img
                              src={URL.createObjectURL(file)}
                              alt={`Preview ${index + 1}`}
                              className="w-full h-20 object-cover rounded"
                            />
                            <Button
                              size="icon"
                              variant="destructive"
                              className="absolute -top-2 -right-2 w-6 h-6"
                              onClick={() => removeFile(index)}
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <Button
                    onClick={editingPost ? handleUpdatePost : handleCreatePost}
                    disabled={isSubmitting}
                    className="w-full"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                        {editingPost ? 'Updating...' : 'Posting...'}
                      </>
                    ) : (
                      editingPost ? 'Update Post' : 'Share Post'
                    )}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : posts.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No posts yet. Be the first to share!</p>
            </div>
          ) : (
            <div className="space-y-6">
              {posts.map((post) => (
                <Card key={post.id} className="travel-card">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <button
                          onClick={() => handleViewProfile(post.user_id)}
                          className="focus:outline-none focus:ring-2 focus:ring-primary rounded-full"
                        >
                          <Avatar className="cursor-pointer hover:ring-2 hover:ring-primary transition-all">
                            <AvatarImage src={post.user?.avatar_url || ''} alt={post.user?.username || 'User'} />
                            <AvatarFallback>
                              {post.user?.username?.[0]?.toUpperCase() || 'U'}
                            </AvatarFallback>
                          </Avatar>
                        </button>
                        <div>
                          <CardTitle className="text-lg">{post.title}</CardTitle>
                          <CardDescription>
                            by{' '}
                            <button
                              onClick={() => handleViewProfile(post.user_id)}
                              className="hover:text-primary hover:underline focus:outline-none focus:text-primary transition-colors"
                            >
                              {post.user?.username || 'Anonymous'}
                            </button>
                            {post.location && ` • ${post.location}`}
                          </CardDescription>
                        </div>
                      </div>
                      {currentUser === post.user_id && (
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-40 p-2" align="end">
                            <div className="flex flex-col gap-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="justify-start"
                                onClick={() => handleEditPost(post)}
                              >
                                <Edit2 className="w-4 h-4 mr-2" />
                                Edit
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="justify-start text-destructive hover:text-destructive"
                                onClick={() => setDeletePostId(post.id)}
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Delete
                              </Button>
                            </div>
                          </PopoverContent>
                        </Popover>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-muted-foreground whitespace-pre-wrap">
                        {translations[post.id] ? translations[post.id].translatedText : post.content}
                      </p>
                      {translations[post.id] && (
                        <div className="mt-2 text-xs text-muted-foreground">
                          Translated from {getLanguageName(translations[post.id].sourceLanguage)} to {getLanguageName(translations[post.id].targetLanguage)}
                        </div>
                      )}
                    </div>
                    
                    {post.images && post.images.length > 0 && (
                      <div className={`grid gap-2 ${post.images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
                        {post.images.map((image, index) => (
                          <img
                            key={index}
                            src={image}
                            alt={`${post.title} ${index + 1}`}
                            className="w-full h-64 object-cover rounded-lg"
                          />
                        ))}
                      </div>
                    )}

                    <div className="flex items-center gap-4 pt-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleLike(post.id)}
                      >
                        <Heart className="w-4 h-4 mr-2" />
                        {post.likes_count}
                      </Button>
                      <Button variant="ghost" size="sm">
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Comment
                      </Button>
                      <TranslateButton
                        text={post.content}
                        onTranslated={(translatedText, sourceLanguage, targetLanguage) =>
                          handleTranslated(post.id, translatedText, sourceLanguage, targetLanguage)
                        }
                        isTranslated={!!translations[post.id]}
                        onReset={() => handleResetTranslation(post.id)}
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      <AlertDialog open={!!deletePostId} onOpenChange={(open) => !open && setDeletePostId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Post</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this post? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeletePost}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? (
                <>
                  <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                'Delete'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <UserProfileDialog
        userId={viewingUserId}
        open={isProfileDialogOpen}
        onOpenChange={setIsProfileDialogOpen}
      />
    </>
  );
};

export default Community;
