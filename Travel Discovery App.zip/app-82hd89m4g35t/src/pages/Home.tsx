import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Sparkles, 
  Cloud, 
  Wallet, 
  Languages, 
  Map, 
  Package, 
  BookOpen,
  ArrowRight,
  Globe,
  Calendar,
  TrendingUp,
  Compass,
  Users,
  Ticket,
  Bot
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import PageMeta from '@/components/common/PageMeta';

const Home: React.FC = () => {
  const features = [
    {
      icon: Bot,
      title: 'AI Travel Assistant',
      description: 'Chat with AI for personalized travel advice and recommendations',
      link: '/ai-assistant',
      color: 'text-primary',
      featured: true,
    },
    {
      icon: Compass,
      title: 'Discover Destinations',
      description: 'Explore historical information and attractions with AI-powered insights',
      link: '/discover',
      color: 'text-primary',
    },
    {
      icon: Users,
      title: 'Travel Community',
      description: 'Share experiences and connect with fellow travelers worldwide',
      link: '/community',
      color: 'text-secondary',
    },
    {
      icon: Sparkles,
      title: 'AI Itinerary Generator',
      description: 'Create personalized travel plans based on your preferences',
      link: '/itinerary',
      color: 'text-primary',
    },
    {
      icon: Ticket,
      title: 'Booking Assistant',
      description: 'Get personalized booking recommendations and tips',
      link: '/booking',
      color: 'text-secondary',
    },
    {
      icon: Cloud,
      title: 'Weather & Events',
      description: 'Live weather forecasts and local events at your destination',
      link: '/weather',
      color: 'text-primary',
    },
    {
      icon: Wallet,
      title: 'Budget Tracker',
      description: 'Track expenses in real-time with spending alerts',
      link: '/budget',
      color: 'text-secondary',
    },
    {
      icon: Languages,
      title: 'Translator',
      description: 'Communicate with locals in any language',
      link: '/translator',
      color: 'text-primary',
    },
    {
      icon: Map,
      title: 'Interactive Map',
      description: 'Save destinations and routes with custom notes',
      link: '/map',
      color: 'text-secondary',
    },
    {
      icon: Package,
      title: 'Packing List',
      description: 'AI-generated lists based on destination and weather',
      link: '/packing',
      color: 'text-primary',
    },
    {
      icon: BookOpen,
      title: 'Travel Journal',
      description: 'Document your journey with photos and memories',
      link: '/journal',
      color: 'text-secondary',
    },
  ];

  const stats = [
    { icon: Globe, label: 'Destinations', value: '195+' },
    { icon: Calendar, label: 'Trips Planned', value: '10K+' },
    { icon: TrendingUp, label: 'Success Rate', value: '98%' },
  ];

  return (
    <>
      <PageMeta 
        title="Travel Discovery - Discover, Connect, Explore"
        description="Discover amazing destinations, connect with fellow travelers, and explore the world with AI-powered tools and a vibrant community"
      />
      
      <div className="min-h-screen">
        <section className="relative py-20 xl:py-32 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-secondary/10" />
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl xl:text-6xl font-bold mb-6">
                <span className="gradient-text">Discover, Connect,</span>
                <br />
                Explore the World
              </h1>
              <p className="text-lg xl:text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
                Your ultimate travel companion with AI-powered planning, historical insights, 
                booking assistance, and a vibrant community of travelers
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" className="text-base">
                  <Link to="/itinerary">
                    Start Planning
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="text-base">
                  <Link to="/weather">
                    Explore Features
                  </Link>
                </Button>
              </div>
            </div>

            <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
              {stats.map((stat, index) => (
                <Card key={index} className="text-center card-hover">
                  <CardContent className="pt-6">
                    <stat.icon className="w-12 h-12 mx-auto mb-4 text-primary" />
                    <div className="text-3xl font-bold text-foreground mb-2">
                      {stat.value}
                    </div>
                    <div className="text-muted-foreground">{stat.label}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl xl:text-4xl font-bold mb-4">
                Powerful Features for Every Traveler
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Everything you need to plan the perfect trip, all in one place
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {features.map((feature, index) => (
                <Link key={index} to={feature.link}>
                  <Card className="h-full travel-card cursor-pointer">
                    <CardHeader>
                      <div className={`w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4`}>
                        <feature.icon className={`w-6 h-6 ${feature.color}`} />
                      </div>
                      <CardTitle className="text-xl">{feature.title}</CardTitle>
                      <CardDescription className="text-base">
                        {feature.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center text-primary font-medium">
                        Learn more
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-12 text-center text-white">
              <h2 className="text-3xl xl:text-4xl font-bold mb-4">
                Ready to Start Your Journey?
              </h2>
              <p className="text-lg mb-8 opacity-90">
                Join thousands of travelers who trust Travel Assistant for their adventures
              </p>
              <Button asChild size="lg" variant="secondary" className="text-base">
                <Link to="/itinerary">
                  Create Your First Itinerary
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;
