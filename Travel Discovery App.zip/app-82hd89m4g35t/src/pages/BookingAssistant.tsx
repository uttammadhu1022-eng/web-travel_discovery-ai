import React, { useState } from 'react';
import { Ticket, Loader2, Plane, Hotel, Car, Calendar } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import PageMeta from '@/components/common/PageMeta';
import { aiAPI } from '@/services/api';
import ReactMarkdown from 'react-markdown';

const BookingAssistant: React.FC = () => {
  const [destination, setDestination] = useState('');
  const [departureCity, setDepartureCity] = useState('');
  const [travelDates, setTravelDates] = useState('');
  const [travelers, setTravelers] = useState('2');
  const [needsFlight, setNeedsFlight] = useState(true);
  const [needsHotel, setNeedsHotel] = useState(true);
  const [needsCar, setNeedsCar] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [bookingInfo, setBookingInfo] = useState('');

  const handleGetBookingInfo = async () => {
    if (!destination || !departureCity || !travelDates) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsLoading(true);

    try {
      const services = [];
      if (needsFlight) services.push('flights');
      if (needsHotel) services.push('accommodation');
      if (needsCar) services.push('car rental');

      const prompt = `Provide comprehensive booking information and tips for a trip:
- Destination: ${destination}
- Departure: ${departureCity}
- Travel Dates: ${travelDates}
- Number of Travelers: ${travelers}
- Services Needed: ${services.join(', ')}

Include:
1. Best booking platforms and websites
2. Estimated costs and budget tips
3. Best time to book for deals
4. Important booking considerations
5. Recommended booking timeline
6. Travel insurance recommendations
7. Cancellation policy tips
8. Local transportation options

Format the response in clear sections with markdown.`;

      const result = await aiAPI.generateContent(prompt);
      setBookingInfo(result);
      toast.success('Booking information generated!');
    } catch (error) {
      console.error('Error generating booking info:', error);
      toast.error('Failed to generate booking information');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <PageMeta title="Booking Assistant - Travel Discovery" description="Get help with travel bookings" />
      
      <div className="min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <Ticket className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Booking Assistant</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Get personalized booking recommendations and tips for your trip
            </p>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Trip Details</CardTitle>
                <CardDescription>Tell us about your travel plans</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="destination">Destination *</Label>
                  <Input
                    id="destination"
                    placeholder="e.g., Barcelona, Spain"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="departure">Departure City *</Label>
                  <Input
                    id="departure"
                    placeholder="e.g., New York"
                    value={departureCity}
                    onChange={(e) => setDepartureCity(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dates">
                    <Calendar className="w-4 h-4 inline mr-2" />
                    Travel Dates *
                  </Label>
                  <Input
                    id="dates"
                    placeholder="e.g., June 15-22, 2025"
                    value={travelDates}
                    onChange={(e) => setTravelDates(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="travelers">Number of Travelers</Label>
                  <Input
                    id="travelers"
                    type="number"
                    min="1"
                    value={travelers}
                    onChange={(e) => setTravelers(e.target.value)}
                  />
                </div>

                <div className="space-y-3">
                  <Label>Services Needed</Label>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="flight"
                        checked={needsFlight}
                        onCheckedChange={(checked) => setNeedsFlight(checked as boolean)}
                      />
                      <Label htmlFor="flight" className="flex items-center cursor-pointer">
                        <Plane className="w-4 h-4 mr-2" />
                        Flight Booking
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="hotel"
                        checked={needsHotel}
                        onCheckedChange={(checked) => setNeedsHotel(checked as boolean)}
                      />
                      <Label htmlFor="hotel" className="flex items-center cursor-pointer">
                        <Hotel className="w-4 h-4 mr-2" />
                        Accommodation
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="car"
                        checked={needsCar}
                        onCheckedChange={(checked) => setNeedsCar(checked as boolean)}
                      />
                      <Label htmlFor="car" className="flex items-center cursor-pointer">
                        <Car className="w-4 h-4 mr-2" />
                        Car Rental
                      </Label>
                    </div>
                  </div>
                </div>

                <Button
                  onClick={handleGetBookingInfo}
                  disabled={isLoading}
                  className="w-full"
                  size="lg"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 w-5 h-5 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Ticket className="mr-2 w-5 h-5" />
                      Get Booking Information
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Booking Recommendations</CardTitle>
                <CardDescription>Personalized booking tips and information</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex flex-col items-center justify-center py-12">
                    <Loader2 className="w-12 h-12 animate-spin text-primary mb-4" />
                    <p className="text-muted-foreground">Generating booking recommendations...</p>
                  </div>
                ) : bookingInfo ? (
                  <div className="prose prose-sm max-w-none bg-muted/30 p-6 rounded-lg max-h-[600px] overflow-y-auto">
                    <ReactMarkdown>{bookingInfo}</ReactMarkdown>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <Ticket className="w-12 h-12 text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">
                      Fill in your trip details to get personalized booking recommendations
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Popular Booking Sites</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Booking.com - Hotels & Accommodation</li>
                  <li>• Expedia - Flights & Packages</li>
                  <li>• Airbnb - Unique Stays</li>
                  <li>• Skyscanner - Flight Comparison</li>
                  <li>• Kayak - Travel Search</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Booking Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Book flights 2-3 months in advance</li>
                  <li>• Compare prices across platforms</li>
                  <li>• Check cancellation policies</li>
                  <li>• Consider travel insurance</li>
                  <li>• Read reviews before booking</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Money-Saving Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Travel during off-peak seasons</li>
                  <li>• Use price alerts and trackers</li>
                  <li>• Consider package deals</li>
                  <li>• Book accommodation with kitchen</li>
                  <li>• Use public transportation</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
};

export default BookingAssistant;
