import React, { useState, useEffect } from 'react';
import { Sparkles, Save, Loader2, Calendar, DollarSign, MapPin } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import PageMeta from '@/components/common/PageMeta';
import { aiAPI } from '@/services/api';
import { createItinerary, getItineraries } from '@/db/api';
import type { Itinerary } from '@/types';
import ReactMarkdown from 'react-markdown';

const ItineraryGenerator: React.FC = () => {
  const [destination, setDestination] = useState('');
  const [days, setDays] = useState('7');
  const [budget, setBudget] = useState('');
  const [preferences, setPreferences] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedItinerary, setGeneratedItinerary] = useState('');
  const [savedItineraries, setSavedItineraries] = useState<Itinerary[]>([]);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadItineraries();
  }, []);

  const loadItineraries = async () => {
    const itineraries = await getItineraries();
    setSavedItineraries(itineraries);
  };

  const handleGenerate = async () => {
    if (!destination || !days || !budget) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsGenerating(true);
    setGeneratedItinerary('');

    try {
      const result = await aiAPI.generateItinerary(
        destination,
        Number.parseInt(days),
        Number.parseFloat(budget),
        preferences || 'General sightseeing and local experiences'
      );

      setGeneratedItinerary(result);
      toast.success('Itinerary generated successfully!');
    } catch (error) {
      console.error('Error generating itinerary:', error);
      toast.error('Failed to generate itinerary. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = async () => {
    if (!generatedItinerary) {
      toast.error('No itinerary to save');
      return;
    }

    setIsSaving(true);

    try {
      const today = new Date();
      const endDate = new Date(today);
      endDate.setDate(today.getDate() + Number.parseInt(days));

      await createItinerary({
        title: `${destination} - ${days} Days`,
        destination,
        start_date: today.toISOString().split('T')[0],
        end_date: endDate.toISOString().split('T')[0],
        budget: Number.parseFloat(budget),
        currency: 'USD',
        content: { itinerary: generatedItinerary, preferences },
      });

      toast.success('Itinerary saved successfully!');
      await loadItineraries();
    } catch (error) {
      console.error('Error saving itinerary:', error);
      toast.error('Failed to save itinerary');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <>
      <PageMeta 
        title="AI Itinerary Generator - Travel Assistant"
        description="Generate personalized travel itineraries with AI"
      />
      
      <div className="min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <Sparkles className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold mb-4">AI Itinerary Generator</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Let AI create a personalized travel plan tailored to your preferences and budget
            </p>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Trip Details</CardTitle>
                <CardDescription>
                  Tell us about your dream destination
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="destination">
                    <MapPin className="w-4 h-4 inline mr-2" />
                    Destination *
                  </Label>
                  <Input
                    id="destination"
                    placeholder="e.g., Paris, France"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="days">
                    <Calendar className="w-4 h-4 inline mr-2" />
                    Number of Days *
                  </Label>
                  <Input
                    id="days"
                    type="number"
                    min="1"
                    max="30"
                    placeholder="7"
                    value={days}
                    onChange={(e) => setDays(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="budget">
                    <DollarSign className="w-4 h-4 inline mr-2" />
                    Budget (USD) *
                  </Label>
                  <Input
                    id="budget"
                    type="number"
                    min="0"
                    placeholder="2000"
                    value={budget}
                    onChange={(e) => setBudget(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="preferences">
                    Preferences & Interests
                  </Label>
                  <Textarea
                    id="preferences"
                    placeholder="e.g., Museums, local cuisine, outdoor activities, photography..."
                    value={preferences}
                    onChange={(e) => setPreferences(e.target.value)}
                    rows={4}
                  />
                </div>

                <Button
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="w-full"
                  size="lg"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="mr-2 w-5 h-5 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 w-5 h-5" />
                      Generate Itinerary
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Generated Itinerary</CardTitle>
                <CardDescription>
                  Your personalized travel plan
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isGenerating ? (
                  <div className="flex flex-col items-center justify-center py-12">
                    <Loader2 className="w-12 h-12 animate-spin text-primary mb-4" />
                    <p className="text-muted-foreground">Creating your perfect itinerary...</p>
                  </div>
                ) : generatedItinerary ? (
                  <div className="space-y-4">
                    <div className="prose prose-sm max-w-none bg-muted/30 p-6 rounded-lg max-h-[600px] overflow-y-auto">
                      <ReactMarkdown>{generatedItinerary}</ReactMarkdown>
                    </div>
                    <Button
                      onClick={handleSave}
                      disabled={isSaving}
                      className="w-full"
                      variant="secondary"
                    >
                      {isSaving ? (
                        <>
                          <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 w-4 h-4" />
                          Save Itinerary
                        </>
                      )}
                    </Button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <Sparkles className="w-12 h-12 text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">
                      Fill in the trip details and click "Generate Itinerary" to get started
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {savedItineraries.length > 0 && (
            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-6">Saved Itineraries</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {savedItineraries.map((itinerary) => (
                  <Card key={itinerary.id} className="travel-card">
                    <CardHeader>
                      <CardTitle className="text-lg">{itinerary.title}</CardTitle>
                      <CardDescription>
                        {itinerary.destination}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-2" />
                          {itinerary.start_date} to {itinerary.end_date}
                        </div>
                        <div className="flex items-center">
                          <DollarSign className="w-4 h-4 mr-2" />
                          ${itinerary.budget} {itinerary.currency}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default ItineraryGenerator;
