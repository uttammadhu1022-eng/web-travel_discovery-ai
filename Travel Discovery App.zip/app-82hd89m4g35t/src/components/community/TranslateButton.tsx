import React, { useState } from 'react';
import { Languages, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { toast } from 'sonner';
import { translateText, SUPPORTED_LANGUAGES, getLanguageName } from '@/services/translationService';

interface TranslateButtonProps {
  text: string;
  onTranslated: (translatedText: string, sourceLanguage: string, targetLanguage: string) => void;
  isTranslated: boolean;
  onReset: () => void;
}

const TranslateButton: React.FC<TranslateButtonProps> = ({
  text,
  onTranslated,
  isTranslated,
  onReset,
}) => {
  const [isTranslating, setIsTranslating] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const handleTranslate = async (targetLanguage: string) => {
    if (isTranslated) {
      onReset();
      return;
    }

    setIsTranslating(true);
    setIsOpen(false);
    try {
      const result = await translateText(text, targetLanguage);
      onTranslated(
        result.translatedText,
        result.detectedSourceLanguage || 'unknown',
        targetLanguage
      );
      toast.success(`Translated to ${getLanguageName(targetLanguage)}`);
    } catch (error) {
      console.error('Translation error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to translate text');
    } finally {
      setIsTranslating(false);
    }
  };

  if (isTranslated) {
    return (
      <Button
        variant="ghost"
        size="sm"
        onClick={onReset}
        className="text-primary"
      >
        <Languages className="w-4 h-4 mr-2" />
        Show Original
      </Button>
    );
  }

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          disabled={isTranslating}
        >
          {isTranslating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Translating...
            </>
          ) : (
            <>
              <Languages className="w-4 h-4 mr-2" />
              Translate
            </>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-64 p-2">
        <div className="text-sm font-medium mb-2 px-2">Select Language</div>
        <div className="max-h-[300px] overflow-y-auto space-y-1">
          {SUPPORTED_LANGUAGES.map((language) => (
            <button
              key={language.code}
              onClick={() => handleTranslate(language.code)}
              className="w-full text-left px-3 py-2 text-sm rounded hover:bg-accent transition-colors"
            >
              {language.name}
            </button>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default TranslateButton;
