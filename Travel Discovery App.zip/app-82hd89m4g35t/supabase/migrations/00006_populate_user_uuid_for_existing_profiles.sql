/*
# Populate user_uuid for Existing Profiles

Update any existing profiles that don't have user_uuid set.
This ensures backward compatibility with code that uses user_uuid.
*/

-- Update profiles where user_uuid is null
UPDATE profiles
SET user_uuid = id::text
WHERE user_uuid IS NULL;
