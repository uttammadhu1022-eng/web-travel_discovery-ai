import React, { useRef, useEffect, useState } from 'react';
import { LoadScript, Autocomplete } from '@react-google-maps/api';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';

interface LocationSearchProps {
  onPlaceSelected: (place: {
    name: string;
    lat: number;
    lng: number;
    address?: string;
  }) => void;
  placeholder?: string;
}

const libraries: ("places")[] = ["places"];

const LocationSearch: React.FC<LocationSearchProps> = ({ 
  onPlaceSelected, 
  placeholder = "Search for a location..." 
}) => {
  const autocompleteRef = useRef<google.maps.places.Autocomplete | null>(null);
  const [searchValue, setSearchValue] = useState('');
  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

  const onLoad = (autocomplete: google.maps.places.Autocomplete) => {
    autocompleteRef.current = autocomplete;
  };

  const onPlaceChanged = () => {
    if (autocompleteRef.current) {
      const place = autocompleteRef.current.getPlace();
      
      if (place.geometry && place.geometry.location) {
        const lat = place.geometry.location.lat();
        const lng = place.geometry.location.lng();
        const name = place.name || place.formatted_address || 'Unknown Location';
        const address = place.formatted_address;

        onPlaceSelected({ name, lat, lng, address });
        setSearchValue('');
      }
    }
  };

  if (!apiKey) {
    return (
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
        <Input
          placeholder="Google Maps API key not configured"
          disabled
          className="pl-10"
        />
      </div>
    );
  }

  return (
    <LoadScript googleMapsApiKey={apiKey} libraries={libraries}>
      <Autocomplete
        onLoad={onLoad}
        onPlaceChanged={onPlaceChanged}
      >
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            type="text"
            placeholder={placeholder}
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            className="pl-10"
          />
        </div>
      </Autocomplete>
    </LoadScript>
  );
};

export default LocationSearch;
