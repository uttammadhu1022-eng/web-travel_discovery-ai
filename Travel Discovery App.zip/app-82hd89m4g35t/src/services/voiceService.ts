// Language code mapping for speech recognition
const speechRecognitionLangMap: Record<string, string> = {
  'en': 'en-US',
  'es': 'es-ES',
  'fr': 'fr-FR',
  'de': 'de-DE',
  'it': 'it-IT',
  'pt': 'pt-PT',
  'zh': 'zh-CN',
  'ja': 'ja-JP',
  'ko': 'ko-KR',
  'ar': 'ar-SA',
  'ru': 'ru-RU',
};

// Check if browser supports speech recognition
export const isSpeechRecognitionSupported = (): boolean => {
  return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
};

// Check if browser supports speech synthesis
export const isSpeechSynthesisSupported = (): boolean => {
  return 'speechSynthesis' in window;
};

// Start speech recognition
export const startSpeechRecognition = (
  languageCode: string,
  onResult: (transcript: string) => void,
  onError: (error: string) => void,
  onEnd: () => void
): SpeechRecognition | null => {
  if (!isSpeechRecognitionSupported()) {
    onError('Speech recognition is not supported in your browser');
    return null;
  }

  const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  const recognition = new SpeechRecognition();

  recognition.lang = speechRecognitionLangMap[languageCode] || 'en-US';
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.onresult = (event: SpeechRecognitionEvent) => {
    const transcript = event.results[0][0].transcript;
    onResult(transcript);
  };

  recognition.onerror = (event: any) => {
    let errorMessage = 'Speech recognition error';
    
    switch (event.error) {
      case 'no-speech':
        errorMessage = 'No speech detected. Please try again.';
        break;
      case 'audio-capture':
        errorMessage = 'No microphone found. Please check your device.';
        break;
      case 'not-allowed':
        errorMessage = 'Microphone permission denied. Please allow microphone access.';
        break;
      case 'network':
        errorMessage = 'Network error. Please check your connection.';
        break;
      default:
        errorMessage = `Speech recognition error: ${event.error}`;
    }
    
    onError(errorMessage);
  };

  recognition.onend = () => {
    onEnd();
  };

  try {
    recognition.start();
    return recognition;
  } catch (error) {
    onError('Failed to start speech recognition');
    return null;
  }
};

// Stop speech recognition
export const stopSpeechRecognition = (recognition: SpeechRecognition | null) => {
  if (recognition) {
    recognition.stop();
  }
};

// Speak text using speech synthesis
export const speakText = (
  text: string,
  languageCode: string,
  onStart: () => void,
  onEnd: () => void,
  onError: (error: string) => void
): void => {
  if (!isSpeechSynthesisSupported()) {
    onError('Speech synthesis is not supported in your browser');
    return;
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = speechRecognitionLangMap[languageCode] || 'en-US';
  utterance.rate = 0.9;
  utterance.pitch = 1;
  utterance.volume = 1;

  // Try to find a voice for the target language
  const voices = window.speechSynthesis.getVoices();
  const targetVoice = voices.find(voice => 
    voice.lang.startsWith(languageCode) || 
    voice.lang.startsWith(speechRecognitionLangMap[languageCode])
  );
  
  if (targetVoice) {
    utterance.voice = targetVoice;
  }

  utterance.onstart = () => {
    onStart();
  };

  utterance.onend = () => {
    onEnd();
  };

  utterance.onerror = (event) => {
    onError(`Speech synthesis error: ${event.error}`);
    onEnd();
  };

  window.speechSynthesis.speak(utterance);
};

// Stop speech synthesis
export const stopSpeaking = (): void => {
  if (isSpeechSynthesisSupported()) {
    window.speechSynthesis.cancel();
  }
};

// Load voices (needed for some browsers)
export const loadVoices = (): Promise<SpeechSynthesisVoice[]> => {
  return new Promise((resolve) => {
    const voices = window.speechSynthesis.getVoices();
    
    if (voices.length > 0) {
      resolve(voices);
    } else {
      window.speechSynthesis.onvoiceschanged = () => {
        resolve(window.speechSynthesis.getVoices());
      };
    }
  });
};
