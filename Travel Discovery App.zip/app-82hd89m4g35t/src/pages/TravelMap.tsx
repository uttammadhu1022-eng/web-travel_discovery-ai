import React, { useState, useEffect, lazy, Suspense } from 'react';
import { Map as MapIcon, Plus, Trash2, MapPin, Navigation, Coffee, Camera, Hotel, Utensils, Fuel, X, Search } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import PageMeta from '@/components/common/PageMeta';
import ErrorBoundary from '@/components/common/ErrorBoundary';
import LocationSearch from '@/components/map/LocationSearch';

// Dynamically import the Google Maps component
const GoogleRouteMap = lazy(() => import('@/components/map/GoogleRouteMap'));

interface RoutePoint {
  id: string;
  name: string;
  lat: number;
  lng: number;
  type: 'destination' | 'poi';
  category?: string;
  description?: string;
}

interface PlaceRecommendation {
  id: string;
  name: string;
  category: string;
  lat: number;
  lng: number;
  description: string;
  distance: string;
}

const TravelMap: React.FC = () => {
  const [routePoints, setRoutePoints] = useState<RoutePoint[]>([]);
  const [recommendations, setRecommendations] = useState<PlaceRecommendation[]>([]);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [newPointName, setNewPointName] = useState('');
  const [newPointLat, setNewPointLat] = useState('');
  const [newPointLng, setNewPointLng] = useState('');
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const categories = [
    { value: 'all', label: 'All Places', icon: MapPin },
    { value: 'restaurant', label: 'Restaurants', icon: Utensils },
    { value: 'hotel', label: 'Hotels', icon: Hotel },
    { value: 'attraction', label: 'Attractions', icon: Camera },
    { value: 'cafe', label: 'Cafes', icon: Coffee },
    { value: 'gas', label: 'Gas Stations', icon: Fuel },
  ];

  // Sample recommendations (in real app, these would come from an API based on route)
  const sampleRecommendations: PlaceRecommendation[] = [
    {
      id: '1',
      name: 'Scenic Viewpoint',
      category: 'attraction',
      lat: 48.8584,
      lng: 2.2945,
      description: 'Beautiful panoramic views of the city',
      distance: '5 km from route'
    },
    {
      id: '2',
      name: 'Le Petit Bistro',
      category: 'restaurant',
      lat: 48.8606,
      lng: 2.3376,
      description: 'Traditional French cuisine',
      distance: '2 km from route'
    },
    {
      id: '3',
      name: 'Cozy Inn',
      category: 'hotel',
      lat: 48.8566,
      lng: 2.3522,
      description: 'Comfortable accommodation with great reviews',
      distance: '1 km from route'
    },
    {
      id: '4',
      name: 'Café de la Paix',
      category: 'cafe',
      lat: 48.8700,
      lng: 2.3318,
      description: 'Historic café with excellent coffee',
      distance: '3 km from route'
    },
  ];

  useEffect(() => {
    // Load sample route points
    const sampleRoute: RoutePoint[] = [
      { id: '1', name: 'Eiffel Tower', lat: 48.8584, lng: 2.2945, type: 'destination' },
      { id: '2', name: 'Louvre Museum', lat: 48.8606, lng: 2.3376, type: 'destination' },
      { id: '3', name: 'Notre-Dame', lat: 48.8530, lng: 2.3499, type: 'destination' },
    ];
    setRoutePoints(sampleRoute);
    setRecommendations(sampleRecommendations);
  }, []);

  const handleAddPoint = () => {
    if (!newPointName || !newPointLat || !newPointLng) {
      toast.error('Please fill all fields');
      return;
    }

    const lat = parseFloat(newPointLat);
    const lng = parseFloat(newPointLng);

    if (isNaN(lat) || isNaN(lng)) {
      toast.error('Invalid coordinates');
      return;
    }

    const newPoint: RoutePoint = {
      id: Date.now().toString(),
      name: newPointName,
      lat,
      lng,
      type: 'destination',
    };

    setRoutePoints([...routePoints, newPoint]);
    toast.success('Destination added to route!');
    setIsAddDialogOpen(false);
    setNewPointName('');
    setNewPointLat('');
    setNewPointLng('');
  };

  const handlePlaceSelected = (place: { name: string; lat: number; lng: number; address?: string }) => {
    const newPoint: RoutePoint = {
      id: Date.now().toString(),
      name: place.name,
      lat: place.lat,
      lng: place.lng,
      type: 'destination',
      description: place.address,
    };

    setRoutePoints([...routePoints, newPoint]);
    toast.success(`${place.name} added to route!`);
    setIsAddDialogOpen(false);
  };

  const handleRemovePoint = (id: string) => {
    setRoutePoints(routePoints.filter(p => p.id !== id));
    toast.success('Point removed from route');
  };

  const handleAddRecommendation = (rec: PlaceRecommendation) => {
    const newPoint: RoutePoint = {
      id: rec.id,
      name: rec.name,
      lat: rec.lat,
      lng: rec.lng,
      type: 'poi',
      category: rec.category,
      description: rec.description,
    };

    setRoutePoints([...routePoints, newPoint]);
    toast.success(`${rec.name} added to route!`);
  };

  const filteredRecommendations = selectedCategory === 'all'
    ? recommendations
    : recommendations.filter(r => r.category === selectedCategory);

  const calculateRouteStats = () => {
    if (routePoints.length < 2) return null;

    // Simple distance calculation (in real app, use proper routing API)
    let totalDistance = 0;
    for (let i = 0; i < routePoints.length - 1; i++) {
      const p1 = routePoints[i];
      const p2 = routePoints[i + 1];
      const distance = Math.sqrt(
        Math.pow(p2.lat - p1.lat, 2) + Math.pow(p2.lng - p1.lng, 2)
      ) * 111; // Rough km conversion
      totalDistance += distance;
    }

    return {
      distance: totalDistance.toFixed(1),
      stops: routePoints.length,
      duration: (totalDistance * 1.5).toFixed(0), // Rough estimate
    };
  };

  const stats = calculateRouteStats();

  const getCategoryIcon = (category?: string) => {
    switch (category) {
      case 'restaurant': return Utensils;
      case 'hotel': return Hotel;
      case 'attraction': return Camera;
      case 'cafe': return Coffee;
      case 'gas': return Fuel;
      default: return MapPin;
    }
  };

  return (
    <>
      <PageMeta title="Travel Map - Travel Assistant" description="Plan your route and discover places along the way" />
      
      <div className="min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <MapIcon className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Interactive Travel Map</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Plan your route and discover amazing places along the way
            </p>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Map Section */}
            <div className="xl:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Your Route</CardTitle>
                      <CardDescription>
                        {routePoints.length === 0 && 'Add destinations to see your route'}
                        {routePoints.length === 1 && '1 destination added'}
                        {routePoints.length > 1 && `${routePoints.length} destinations on your route`}
                      </CardDescription>
                    </div>
                    <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                      <DialogTrigger asChild>
                        <Button>
                          <Plus className="mr-2 w-4 h-4" />
                          Add Destination
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Add Destination</DialogTitle>
                          <DialogDescription>Search and add a new point to your route</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label>Search Location</Label>
                            <LocationSearch 
                              onPlaceSelected={handlePlaceSelected}
                              placeholder="Search for a place (e.g., Eiffel Tower, Paris)"
                            />
                            <p className="text-xs text-muted-foreground">
                              Start typing to search for locations using Google Maps
                            </p>
                          </div>
                          
                          <div className="relative">
                            <div className="absolute inset-0 flex items-center">
                              <span className="w-full border-t" />
                            </div>
                            <div className="relative flex justify-center text-xs uppercase">
                              <span className="bg-background px-2 text-muted-foreground">
                                Or enter manually
                              </span>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <Label>Place Name</Label>
                            <Input
                              placeholder="e.g., Eiffel Tower"
                              value={newPointName}
                              onChange={(e) => setNewPointName(e.target.value)}
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label>Latitude</Label>
                              <Input
                                type="number"
                                step="any"
                                placeholder="e.g., 48.8584"
                                value={newPointLat}
                                onChange={(e) => setNewPointLat(e.target.value)}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label>Longitude</Label>
                              <Input
                                type="number"
                                step="any"
                                placeholder="e.g., 2.2945"
                                value={newPointLng}
                                onChange={(e) => setNewPointLng(e.target.value)}
                              />
                            </div>
                          </div>
                          <Button onClick={handleAddPoint} className="w-full" variant="outline">
                            Add Manually
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="h-[500px] rounded-lg overflow-hidden border">
                    {routePoints.length > 0 && isClient ? (
                      <ErrorBoundary
                        fallback={
                          <div className="h-full flex items-center justify-center bg-muted/20">
                            <div className="text-center">
                              <MapIcon className="w-16 h-16 mx-auto text-destructive mb-4" />
                              <p className="text-muted-foreground mb-2">Failed to load map</p>
                              <p className="text-sm text-muted-foreground">Please try refreshing the page</p>
                            </div>
                          </div>
                        }
                      >
                        <Suspense fallback={
                          <div className="h-full flex items-center justify-center bg-muted/20">
                            <div className="text-center">
                              <MapIcon className="w-16 h-16 mx-auto text-muted-foreground mb-4 animate-pulse" />
                              <p className="text-muted-foreground">Loading map...</p>
                            </div>
                          </div>
                        }>
                          <GoogleRouteMap routePoints={routePoints} />
                        </Suspense>
                      </ErrorBoundary>
                    ) : (
                      <div className="h-full flex items-center justify-center bg-muted/20">
                        <div className="text-center">
                          <MapIcon className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                          <p className="text-muted-foreground">
                            {!isClient ? 'Loading map...' : 'Add destinations to see your route on the map'}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Route Stats */}
                  {stats && (
                    <div className="grid grid-cols-3 gap-4 mt-4">
                      <div className="bg-muted/30 p-4 rounded-lg text-center">
                        <p className="text-2xl font-bold text-primary">{stats.distance} km</p>
                        <p className="text-sm text-muted-foreground">Total Distance</p>
                      </div>
                      <div className="bg-muted/30 p-4 rounded-lg text-center">
                        <p className="text-2xl font-bold text-primary">{stats.stops}</p>
                        <p className="text-sm text-muted-foreground">Stops</p>
                      </div>
                      <div className="bg-muted/30 p-4 rounded-lg text-center">
                        <p className="text-2xl font-bold text-primary">{stats.duration} min</p>
                        <p className="text-sm text-muted-foreground">Est. Duration</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Route Points List */}
              {routePoints.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Route Details</CardTitle>
                    <CardDescription>Your journey stops in order</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {routePoints.map((point, index) => {
                        const Icon = getCategoryIcon(point.category);
                        return (
                          <div
                            key={point.id}
                            className="flex items-center justify-between p-3 bg-muted/30 rounded-lg"
                          >
                            <div className="flex items-center gap-3">
                              <div className="flex items-center justify-center w-8 h-8 bg-primary text-primary-foreground rounded-full text-sm font-bold">
                                {index + 1}
                              </div>
                              <Icon className="w-5 h-5 text-primary" />
                              <div>
                                <p className="font-medium">{point.name}</p>
                                <p className="text-sm text-muted-foreground">
                                  {point.lat.toFixed(4)}, {point.lng.toFixed(4)}
                                </p>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleRemovePoint(point.id)}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Recommendations Sidebar */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Places Along Route</CardTitle>
                  <CardDescription>Discover interesting stops</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Filter by Category</Label>
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat.value} value={cat.value}>
                            {cat.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-3">
                    {filteredRecommendations.map((rec) => {
                      const Icon = getCategoryIcon(rec.category);
                      return (
                        <Card key={rec.id} className="overflow-hidden">
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex items-start gap-2">
                                <Icon className="w-5 h-5 text-primary mt-0.5" />
                                <div>
                                  <p className="font-medium">{rec.name}</p>
                                  <Badge variant="secondary" className="text-xs mt-1">
                                    {rec.category}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">
                              {rec.description}
                            </p>
                            <div className="flex items-center justify-between">
                              <p className="text-xs text-muted-foreground flex items-center gap-1">
                                <Navigation className="w-3 h-3" />
                                {rec.distance}
                              </p>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleAddRecommendation(rec)}
                              >
                                <Plus className="w-3 h-3 mr-1" />
                                Add
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>

                  {filteredRecommendations.length === 0 && (
                    <div className="text-center py-8">
                      <MapPin className="w-12 h-12 mx-auto text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">
                        No places found in this category
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default TravelMap;
