/*
# Fix Profiles Table user_uuid Constraint

The profiles table has user_uuid as NOT NULL, but the new auth trigger
doesn't populate this field. Since we're using id (from auth.users) as
the primary key, user_uuid should be nullable.

## Changes
1. Make user_uuid nullable
2. Update trigger to populate user_uuid for backward compatibility
*/

-- Make user_uuid nullable
ALTER TABLE profiles ALTER COLUMN user_uuid DROP NOT NULL;

-- Update the trigger function to also populate user_uuid
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
  username_val text;
BEGIN
  -- Check if profile already exists
  IF EXISTS (SELECT 1 FROM profiles WHERE id = NEW.id) THEN
    RETURN NEW;
  END IF;
  
  SELECT COUNT(*) INTO user_count FROM profiles;
  
  -- Extract username from email (before @)
  username_val := split_part(NEW.email, '@', 1);
  
  INSERT INTO profiles (id, user_uuid, email, username, role)
  VALUES (
    NEW.id,
    NEW.id::text,  -- Use auth user id as user_uuid for compatibility
    NEW.email,
    username_val,
    CASE WHEN user_count = 0 THEN 'admin'::user_role ELSE 'user'::user_role END
  )
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
END;
$$;
