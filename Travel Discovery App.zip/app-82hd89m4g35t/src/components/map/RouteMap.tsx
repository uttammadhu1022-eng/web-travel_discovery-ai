import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface RoutePoint {
  id: string;
  name: string;
  lat: number;
  lng: number;
  type: 'destination' | 'poi';
  category?: string;
  description?: string;
}

interface RouteMapProps {
  routePoints: RoutePoint[];
}

// Component to fit map bounds to route
const FitBounds: React.FC<{ points: RoutePoint[] }> = ({ points }) => {
  const map = useMap();

  useEffect(() => {
    if (points.length > 0) {
      const bounds = L.latLngBounds(points.map(p => [p.lat, p.lng]));
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [points, map]);

  return null;
};

const RouteMap: React.FC<RouteMapProps> = ({ routePoints }) => {
  const routeCoordinates: [number, number][] = routePoints.map(p => [p.lat, p.lng]);

  useEffect(() => {
    // Fix Leaflet default marker icon issue
    try {
      delete (L.Icon.Default.prototype as any)._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
      });
    } catch (error) {
      console.error('Error initializing Leaflet icons:', error);
    }
  }, []);

  if (routePoints.length === 0) {
    return (
      <div className="h-full flex items-center justify-center bg-muted/20">
        <p className="text-muted-foreground">No route points to display</p>
      </div>
    );
  }

  return (
    <MapContainer
      center={[routePoints[0].lat, routePoints[0].lng]}
      zoom={13}
      style={{ height: '100%', width: '100%' }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      
      {/* Route markers */}
      {routePoints.map((point, index) => (
        <Marker key={point.id} position={[point.lat, point.lng]}>
          <Popup>
            <div className="text-center">
              <p className="font-semibold">{point.name}</p>
              <p className="text-sm text-muted-foreground">
                Stop {index + 1} of {routePoints.length}
              </p>
              {point.description && (
                <p className="text-sm mt-1">{point.description}</p>
              )}
            </div>
          </Popup>
        </Marker>
      ))}

      {/* Route line */}
      {routePoints.length > 1 && (
        <Polyline
          positions={routeCoordinates}
          color="#1E88E5"
          weight={4}
          opacity={0.7}
        />
      )}

      <FitBounds points={routePoints} />
    </MapContainer>
  );
};

export default RouteMap;
