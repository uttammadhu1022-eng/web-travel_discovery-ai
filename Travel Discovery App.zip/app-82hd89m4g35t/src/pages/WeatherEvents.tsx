import React, { useState } from 'react';
import { Cloud, Search, Loader2, Thermometer, Droplets, Wind, Newspaper } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import PageMeta from '@/components/common/PageMeta';
import { weatherAPI, newsAPI } from '@/services/api';
import type { WeatherData, NewsArticle } from '@/types';

const WeatherEvents: React.FC = () => {
  const [city, setCity] = useState('');
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [news, setNews] = useState<NewsArticle[]>([]);
  const [isLoadingWeather, setIsLoadingWeather] = useState(false);
  const [isLoadingNews, setIsLoadingNews] = useState(false);

  const handleGetWeather = async () => {
    if (!latitude || !longitude) {
      toast.error('Please enter latitude and longitude');
      return;
    }

    setIsLoadingWeather(true);

    try {
      const data = await weatherAPI.getCurrentWeather(
        Number.parseFloat(latitude),
        Number.parseFloat(longitude)
      );

      if (data) {
        setWeather(data);
        setCity(data.city);
        toast.success('Weather data loaded successfully!');
      } else {
        toast.error('Failed to fetch weather data');
      }
    } catch (error) {
      console.error('Error fetching weather:', error);
      toast.error('Failed to fetch weather data');
    } finally {
      setIsLoadingWeather(false);
    }
  };

  const handleGetNews = async () => {
    if (!city) {
      toast.error('Please enter a city name or get weather data first');
      return;
    }

    setIsLoadingNews(true);

    try {
      const articles = await newsAPI.getNews(`${city} events tourism`, 10);
      setNews(articles);
      
      if (articles.length > 0) {
        toast.success('Local news and events loaded!');
      } else {
        toast.info('No recent news found for this location');
      }
    } catch (error) {
      console.error('Error fetching news:', error);
      toast.error('Failed to fetch news');
    } finally {
      setIsLoadingNews(false);
    }
  };

  const useCurrentLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLatitude(position.coords.latitude.toFixed(4));
          setLongitude(position.coords.longitude.toFixed(4));
          toast.success('Location detected!');
        },
        (error) => {
          console.error('Error getting location:', error);
          toast.error('Failed to get your location');
        }
      );
    } else {
      toast.error('Geolocation is not supported by your browser');
    }
  };

  return (
    <>
      <PageMeta 
        title="Weather & Events - Travel Assistant"
        description="Check real-time weather and local events at your destination"
      />
      
      <div className="min-h-screen py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <Cloud className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Weather & Events</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Get real-time weather forecasts and discover local events at your destination
            </p>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Location</CardTitle>
                <CardDescription>
                  Enter coordinates or use your current location
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="latitude">Latitude</Label>
                    <Input
                      id="latitude"
                      type="number"
                      step="0.0001"
                      placeholder="40.7128"
                      value={latitude}
                      onChange={(e) => setLatitude(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="longitude">Longitude</Label>
                    <Input
                      id="longitude"
                      type="number"
                      step="0.0001"
                      placeholder="-74.0060"
                      value={longitude}
                      onChange={(e) => setLongitude(e.target.value)}
                    />
                  </div>
                </div>

                <Button
                  onClick={useCurrentLocation}
                  variant="outline"
                  className="w-full"
                >
                  Use Current Location
                </Button>

                <Button
                  onClick={handleGetWeather}
                  disabled={isLoadingWeather}
                  className="w-full"
                >
                  {isLoadingWeather ? (
                    <>
                      <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                      Loading...
                    </>
                  ) : (
                    <>
                      <Search className="mr-2 w-4 h-4" />
                      Get Weather
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {weather && (
              <Card>
                <CardHeader>
                  <CardTitle>{weather.city}, {weather.country}</CardTitle>
                  <CardDescription className="capitalize">
                    {weather.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-6">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Thermometer className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold">{Math.round(weather.temp)}°C</div>
                        <div className="text-sm text-muted-foreground">Temperature</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                        <Droplets className="w-6 h-6 text-secondary" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold">{weather.humidity}%</div>
                        <div className="text-sm text-muted-foreground">Humidity</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Wind className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold">{weather.wind_speed} m/s</div>
                        <div className="text-sm text-muted-foreground">Wind Speed</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                        <Thermometer className="w-6 h-6 text-secondary" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold">{Math.round(weather.feels_like)}°C</div>
                        <div className="text-sm text-muted-foreground">Feels Like</div>
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={handleGetNews}
                    disabled={isLoadingNews}
                    className="w-full mt-6"
                    variant="secondary"
                  >
                    {isLoadingNews ? (
                      <>
                        <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                        Loading Events...
                      </>
                    ) : (
                      <>
                        <Newspaper className="mr-2 w-4 h-4" />
                        Load Local Events
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {news.length > 0 && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Local News & Events</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {news.map((article) => (
                  <a
                    key={article.uuid}
                    href={article.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block"
                  >
                    <Card className="h-full travel-card cursor-pointer">
                      {article.image_url && (
                        <div className="aspect-video w-full overflow-hidden">
                          <img
                            src={article.image_url}
                            alt={article.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                      <CardHeader>
                        <CardTitle className="text-base line-clamp-2">
                          {article.title}
                        </CardTitle>
                        <CardDescription className="line-clamp-3">
                          {article.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-xs text-muted-foreground">
                          {article.source} • {new Date(article.published_at).toLocaleDateString()}
                        </div>
                      </CardContent>
                    </Card>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default WeatherEvents;
